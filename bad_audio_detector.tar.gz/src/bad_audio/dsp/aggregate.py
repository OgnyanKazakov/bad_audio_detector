from __future__ import annotations


def window_bounds(n_samples: int, window_samples: int, hop_samples: int) -> list[tuple[int, int]]:
    if n_samples <= 0 or window_samples <= 0 or hop_samples <= 0:
        return []
    out: list[tuple[int, int]] = []
    start = 0
    while start + window_samples <= n_samples:
        out.append((start, start + window_samples))
        start += hop_samples
    if not out:
        out.append((0, n_samples))
    elif out[-1][1] < n_samples:
        out.append((max(0, n_samples - window_samples), n_samples))
    return out
