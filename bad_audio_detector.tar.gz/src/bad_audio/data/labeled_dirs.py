from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class LabeledRecord:
    path: Path
    label: int
    sha256: str

    @property
    def label_name(self) -> str:
        return "correct_decoder" if self.label == 0 else "incorrect_decoder"


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _scan_dir(directory: str | Path, label: int, recursive: bool) -> list[LabeledRecord]:
    root = Path(directory)
    if not root.exists():
        return []
    pattern = "**/*" if recursive else "*"
    records = []
    for path in sorted(root.glob(pattern)):
        if not path.is_file() or path.suffix.lower() != ".mp3":
            continue
        records.append(LabeledRecord(path=path, label=label, sha256=_hash_file(path)))
    return records


def scan_labeled_dirs(
    good_dir: str | Path,
    bad_dir: str | Path,
    recursive: bool = True,
) -> list[LabeledRecord]:
    records = _scan_dir(good_dir, 0, recursive) + _scan_dir(bad_dir, 1, recursive)
    seen: set[str] = set()
    unique: list[LabeledRecord] = []
    for record in records:
        if record.sha256 in seen:
            continue
        seen.add(record.sha256)
        unique.append(record)
    return unique


def split_records(
    records: list[LabeledRecord], eval_fraction: float = 0.2
) -> tuple[list[LabeledRecord], list[LabeledRecord]]:
    fraction = min(max(eval_fraction, 0.0), 1.0)
    train: list[LabeledRecord] = []
    evaluation: list[LabeledRecord] = []
    for record in records:
        bucket = int(record.sha256[:8], 16) / 0xFFFFFFFF
        (evaluation if bucket < fraction else train).append(record)
    return train, evaluation
