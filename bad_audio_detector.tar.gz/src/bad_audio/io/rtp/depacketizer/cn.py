from __future__ import annotations

from .base import Depacketizer, EncodedFrame


class CN_Depacketizer(Depacketizer):
    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        if not packet.payload:
            return []
        return [
            EncodedFrame(
                codec=spec.encoding,
                data=b"",
                rtp_timestamp=packet.timestamp,
                duration=160,
                sample_rate=spec.sample_rate,
                valid=False,
                speech=False,
                frame_type="cn",
                sequence=packet.sequence,
            )
        ]
