from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np

from ..config import Settings
from ..detect.decision import decide
from ..io.audio import read_pcm
from ..io.rtp.depacketizer import EncodedFrame, depacketize, make_spec
from ..io.rtp.header import parse_rtp
from ..io.rtp.jitter import JitterBuffer
from ..io.rtp.sdp import parse_sdp
from ..io.rtp.specs import CodecSpec, spec_from_pt
from ..pipeline import AnalysisResult, Detector, WindowResult


@dataclass
class StreamSession:
    detector: Detector
    settings: Settings
    kind: str
    sample_rate: int = 16000
    pcm_format: str = "s16le"
    spec: CodecSpec | None = None
    jitter: JitterBuffer | None = None
    pcm_buffer: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))
    valid_buffer: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=bool))
    frames_buffer: list[EncodedFrame] = field(default_factory=list)
    emitted: list[WindowResult] = field(default_factory=list)
    evidence: dict[str, float] = field(default_factory=dict)

    def feed(self, data: bytes) -> list[WindowResult]:
        if self.kind == "pcm":
            return self._feed_pcm(data)
        return self._feed_rtp(data)

    def _feed_pcm(self, data: bytes) -> list[WindowResult]:
        chunk = read_pcm(data, self.sample_rate, self.pcm_format)
        if chunk.size == 0:
            return []
        self.pcm_buffer = np.concatenate([self.pcm_buffer, chunk])
        self.valid_buffer = np.concatenate(
            [self.valid_buffer, np.ones(chunk.size, dtype=bool)]
        )
        return self._drain_pcm()

    def _drain_pcm(self) -> list[WindowResult]:
        sr = self.settings.target_sample_rate
        window_samples = max(1, int(self.settings.window_seconds * sr))
        hop_samples = max(1, int(self.settings.hop_seconds * sr))
        emitted: list[WindowResult] = []
        while self.pcm_buffer.size >= window_samples:
            pane = self.pcm_buffer[:window_samples]
            mask = self.valid_buffer[:window_samples]
            result = self.detector.analyze_pcm(pane, mask)
            emitted.extend(result.windows)
            self.emitted.extend(result.windows)
            self.evidence = result.evidence or self.evidence
            self.pcm_buffer = self.pcm_buffer[hop_samples:]
            self.valid_buffer = self.valid_buffer[hop_samples:]
        return emitted

    def _feed_rtp(self, data: bytes) -> list[WindowResult]:
        self._require_rtp()
        packet = parse_rtp(data)
        self.jitter.push(packet)
        for ready in self.jitter.drain():
            self.frames_buffer.extend(depacketize(ready, self.spec))
        return self._drain_rtp()

    def _drain_rtp(self) -> list[WindowResult]:
        if self.spec is None:
            return []
        target_sr = self.settings.target_sample_rate
        window_samples = max(1, int(self.settings.window_seconds * target_sr))
        emitted: list[WindowResult] = []

        def samples(frame: EncodedFrame) -> int:
            return max(
                0,
                int(round(frame.duration * target_sr / max(1, self.spec.rtp_clock_rate))),
            )

        while sum(samples(f) for f in self.frames_buffer) >= window_samples:
            taken: list[EncodedFrame] = []
            total = 0
            while self.frames_buffer and total < window_samples:
                item = self.frames_buffer.pop(0)
                taken.append(item)
                total += samples(item)
            result = self.detector.analyze_frames(taken, self.spec)
            emitted.extend(result.windows)
            self.emitted.extend(result.windows)
            self.evidence = result.evidence or self.evidence
            # The next window advances by one hop; the frames already consumed
            # cover the current window, so nothing else to drop here.
        return emitted

    def _require_rtp(self) -> None:
        if self.kind != "rtp" or self.spec is None or self.jitter is None:
            raise ValueError("RTP session is not configured")

    def finish(self) -> AnalysisResult:
        if self.kind == "rtp" and self.jitter is not None and self.spec is not None:
            for ready in self.jitter.flush():
                self.frames_buffer.extend(depacketize(ready, self.spec))
        if self.kind == "pcm" and self.pcm_buffer.size:
            tail = self.detector.analyze_pcm(self.pcm_buffer, self.valid_buffer)
            self.emitted.extend(tail.windows)
            self.evidence = tail.evidence or self.evidence
        elif self.kind == "rtp" and self.frames_buffer and self.spec is not None:
            tail = self.detector.analyze_frames(self.frames_buffer, self.spec)
            self.emitted.extend(tail.windows)
            self.evidence = tail.evidence or self.evidence
            self.frames_buffer.clear()

        sufficient = [w for w in self.emitted if not w.insufficient]
        if not sufficient:
            return AnalysisResult(
                verdict="correct_decoder",
                confidence=None,
                insufficient_signal=True,
                windows=self.emitted,
                evidence=self.evidence,
                model_version=self.detector.model_version,
            )
        scores = [w.p_incorrect for w in sufficient]
        verdict = decide(
            scores,
            threshold=self.detector.threshold,
            consecutive=self.settings.consecutive_windows,
        )
        max_score = max(scores)
        confidence = max_score if verdict == "incorrect_decoder" else 1.0 - max_score
        return AnalysisResult(
            verdict=verdict,
            confidence=float(np.clip(confidence, 0.0, 1.0)),
            insufficient_signal=False,
            windows=self.emitted,
            evidence=self.evidence,
            model_version=self.detector.model_version,
        )


def create_session(detector: Detector, settings: Settings, config: dict) -> StreamSession:
    kind = str(config.get("format", "pcm")).lower()
    if kind == "pcm":
        return StreamSession(
            detector=detector,
            settings=settings,
            kind="pcm",
            sample_rate=int(config.get("sample_rate", settings.target_sample_rate)),
            pcm_format=str(config.get("pcm_format", "s16le")),
        )
    if kind != "rtp":
        raise ValueError("format must be 'pcm' or 'rtp'")
    if not settings.rtp_decode:
        raise ValueError("RTP decoding is disabled by RTP_DECODE")

    spec: CodecSpec | None = None
    sdp = config.get("sdp")
    if sdp:
        specs = parse_sdp(str(sdp))
        if not specs:
            raise ValueError("SDP contains no audio payload types")
        payload_type = config.get("payload_type")
        if payload_type is not None:
            spec = specs.get(int(payload_type))
            if spec is None:
                raise ValueError(f"payload type {payload_type} not found in SDP")
        else:
            spec = next(iter(specs.values()))
    elif config.get("codec"):
        codec = str(config["codec"])
        overrides = {}
        if "clock_rate" in config:
            overrides["rtp_clock_rate"] = int(config["clock_rate"])
        if "sample_rate" in config:
            overrides["sample_rate"] = int(config["sample_rate"])
        if "channels" in config:
            overrides["channels"] = int(config["channels"])
        if "octet_align" in config:
            overrides["octet_align"] = bool(int(config["octet_align"]))
        if "amr_crc" in config:
            overrides["amr_crc"] = bool(int(config["amr_crc"]))
        if "interleaving" in config:
            overrides["interleaving"] = bool(int(config["interleaving"]))
        spec = make_spec(codec, max_frames_per_packet=settings.max_frames_per_packet, **overrides)
    else:
        payload_type = int(config.get("payload_type", 0))
        mapping = {}
        if settings.payload_type_map:
            import json

            try:
                mapping = json.loads(settings.payload_type_map)
            except json.JSONDecodeError as exc:
                raise ValueError("PAYLOAD_TYPE_MAP must be valid JSON") from exc
        if str(payload_type) in mapping:
            spec = make_spec(
                str(mapping[str(payload_type)]),
                max_frames_per_packet=settings.max_frames_per_packet,
            )
        else:
            spec = spec_from_pt(payload_type)

    spec = replace(spec, max_frames_per_packet=settings.max_frames_per_packet)
    depth = max(1, int(settings.jitter_buffer_ms / 20))
    return StreamSession(
        detector=detector,
        settings=settings,
        kind="rtp",
        spec=spec,
        jitter=JitterBuffer(depth=depth),
    )
