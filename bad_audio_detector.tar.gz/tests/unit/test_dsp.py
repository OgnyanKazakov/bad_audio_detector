from __future__ import annotations

import numpy as np

from bad_audio.dsp.aggregate import window_bounds
from bad_audio.dsp.features import extract_features, feature_names, feature_vector
from bad_audio.dsp.framing import frame_signal
from bad_audio.dsp.tones import detect_dtmf
from bad_audio.dsp.vad import vad_mask


def sine(sr: int, seconds: float, freq: float = 440.0, amp: float = 0.2) -> np.ndarray:
    t = np.arange(int(sr * seconds)) / sr
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_framing_shape():
    x = sine(16000, 1.0)
    frames = frame_signal(x, 512, 160)
    assert frames.shape[1] == 512
    assert 96 <= frames.shape[0] <= 100


def test_vad_marks_speech_not_silence():
    sr = 16000
    x = np.concatenate([np.zeros(sr, np.float32), sine(sr, 1.0)])
    frames = frame_signal(x, 512, 160)
    active = vad_mask(frames, sr, threshold=0.01)
    assert active[:90].mean() < 0.1
    assert active[110:].mean() > 0.9


def test_dtmf_detects_digit_one():
    sr = 16000
    t = np.arange(int(sr * 0.2)) / sr
    x = (0.2 * np.sin(2 * np.pi * 697 * t) + 0.2 * np.sin(2 * np.pi * 1209 * t)).astype(
        np.float32
    )
    # Pad with silence so the detector has context.
    x = np.concatenate([np.zeros(sr // 10, np.float32), x, np.zeros(sr // 10, np.float32)])
    events = detect_dtmf(x, sr)
    assert any(event.digit == "1" for event in events)


def test_feature_extraction_is_deterministic_and_separates_noise():
    sr = 16000
    tone = sine(sr, 1.0)
    rng = np.random.default_rng(0)
    noise = (0.2 * rng.standard_normal(sr)).astype(np.float32)
    a = extract_features(tone)
    b = extract_features(tone)
    c = extract_features(noise)
    assert np.allclose(feature_vector(a), feature_vector(b), rtol=0, atol=1e-9)
    assert len(a) == len(feature_names())
    assert np.isfinite(list(a.values())).all()
    assert c["flatness_mean"] > a["flatness_mean"]
    assert a["hnr_mean"] > c["hnr_mean"]
    assert a["active_fraction"] > 0.9


def test_short_and_silent_audio_is_neutral():
    feats = extract_features(np.zeros(4000, dtype=np.float32))
    assert feats["active_fraction"] == 0.0
    assert feats["insufficient_signal"] == 1.0


def test_window_bounds():
    assert window_bounds(16000, 16000, 8000) == [(0, 16000)]
    assert window_bounds(32000, 16000, 8000) == [(0, 16000), (8000, 24000), (16000, 32000)]
    assert window_bounds(10000, 16000, 8000) == [(0, 10000)]
