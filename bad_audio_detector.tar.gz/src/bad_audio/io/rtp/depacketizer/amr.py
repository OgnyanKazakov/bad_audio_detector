from __future__ import annotations

from .base import Depacketizer, EncodedFrame

# Total speech bits per AMR frame type (RFC 4867 / 3GPP TS 26.101).
AMR_NB_BITS: dict[int, int] = {
    0: 95,
    1: 103,
    2: 118,
    3: 134,
    4: 148,
    5: 159,
    6: 204,
    7: 244,
    8: 39,  # SID
    14: 0,  # SPEECH_LOST (AMR-WB only, tolerated)
    15: 0,  # NO_DATA
}
AMR_WB_BITS: dict[int, int] = {
    0: 132,
    1: 177,
    2: 253,
    3: 285,
    4: 317,
    5: 365,
    6: 397,
    7: 461,
    8: 477,
    9: 40,  # SID
    14: 0,  # SPEECH_LOST
    15: 0,  # NO_DATA
}


class _BitReader:
    def __init__(self, data: bytes) -> None:
        self.data = data
        self.bit = 0

    def read(self, width: int) -> int:
        value = 0
        for _ in range(width):
            byte_index = self.bit >> 3
            if byte_index >= len(self.data):
                raise ValueError("truncated AMR payload")
            bit = (self.data[byte_index] >> (7 - (self.bit & 7))) & 1
            value = (value << 1) | bit
            self.bit += 1
        return value

    def align(self) -> None:
        self.bit = (self.bit + 7) & ~7

    def read_bytes(self, width: int) -> bytes:
        nbytes = (width + 7) // 8
        out = bytearray()
        for index in range(nbytes):
            remaining = width - index * 8
            chunk = min(8, remaining)
            out.append(self.read(chunk) << (8 - chunk))
        return bytes(out)


class AmrDepacketizer(Depacketizer):
    NB_FRAME_SAMPLES = 160
    WB_FRAME_SAMPLES = 320

    def __init__(self, wideband: bool) -> None:
        self.wideband = wideband
        self.bits = AMR_WB_BITS if wideband else AMR_NB_BITS
        self.frame_samples = self.WB_FRAME_SAMPLES if wideband else self.NB_FRAME_SAMPLES
        self.codec = "AMR-WB" if wideband else "AMR-NB"

    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        if spec.channels != 1:
            raise NotImplementedError("multichannel AMR depacketization is not supported yet")
        if spec.interleaving:
            raise NotImplementedError("interleaved AMR payloads are not supported")
        if spec.robust_sorting:
            raise NotImplementedError("robust-sorted AMR payloads are not supported")
        if not packet.payload:
            return []
        entries, frame_data = (
            self._parse_octet_aligned(packet.payload, spec)
            if spec.octet_align
            else self._parse_bandwidth_efficient(packet.payload, spec)
        )
        frames: list[EncodedFrame] = []
        for index, (ft, quality, raw, valid, speech, frame_type) in enumerate(entries):
            header = bytes([(ft << 3) | (quality << 2)]) if raw is not None else b""
            frames.append(
                EncodedFrame(
                    codec=self.codec,
                    data=header + (raw or b""),
                    rtp_timestamp=(packet.timestamp + index * self.frame_samples) & 0xFFFFFFFF,
                    duration=self.frame_samples,
                    sample_rate=spec.sample_rate,
                    valid=valid,
                    speech=speech,
                    frame_type=frame_type,
                    sequence=packet.sequence,
                )
            )
        return frames

    def _classify(self, ft: int) -> tuple[int, bool, bool, str]:
        if ft not in self.bits:
            raise ValueError(f"invalid AMR frame type {ft}")
        nbits = self.bits[ft]
        sid_ft = 9 if self.wideband else 8
        if ft == 15:
            return 0, False, False, "no_data"
        if ft == 14:
            if not self.wideband:
                raise ValueError("invalid AMR-NB frame type 14")
            return 0, False, False, "speech_lost"
        if ft == sid_ft:
            return nbits, True, False, "sid"
        return nbits, True, True, "speech"

    def _parse_bandwidth_efficient(self, payload: bytes, spec):
        reader = _BitReader(payload)
        _cmr = reader.read(4)
        toc: list[tuple[int, int]] = []
        while True:
            follow = reader.read(1)
            ft = reader.read(4)
            quality = reader.read(1)
            toc.append((ft, quality))
            if len(toc) > spec.max_frames_per_packet:
                raise ValueError("too many AMR frames in one packet")
            if not follow:
                break
        entries = []
        for ft, quality in toc:
            nbits, valid, speech, frame_type = self._classify(ft)
            if nbits:
                raw = reader.read_bytes(nbits)
            else:
                raw = None
            entries.append((ft, quality, raw, valid, speech, frame_type))
        return entries, None

    def _parse_octet_aligned(self, payload: bytes, spec):
        if len(payload) < 1:
            raise ValueError("truncated AMR payload header")
        offset = 1  # CMR + reserved
        toc: list[tuple[int, int]] = []
        while True:
            if offset >= len(payload):
                raise ValueError("truncated AMR TOC")
            b = payload[offset]
            offset += 1
            follow = (b >> 7) & 1
            ft = (b >> 3) & 0x0F
            quality = (b >> 2) & 1
            toc.append((ft, quality))
            if len(toc) > spec.max_frames_per_packet:
                raise ValueError("too many AMR frames in one packet")
            if not follow:
                break

        classified = [self._classify(ft) for ft, _ in toc]
        if spec.amr_crc:
            crc_count = sum(1 for nbits, _, _, _ in classified if nbits > 0)
            offset += crc_count
            if offset > len(payload):
                raise ValueError("truncated AMR CRC list")

        entries = []
        for (ft, quality), (nbits, valid, speech, frame_type) in zip(toc, classified):
            if nbits:
                nbytes = (nbits + 7) // 8
                raw = payload[offset : offset + nbytes]
                if len(raw) != nbytes:
                    raise ValueError("truncated AMR speech frame")
                offset += nbytes
            else:
                raw = None
            entries.append((ft, quality, raw, valid, speech, frame_type))
        return entries, None
