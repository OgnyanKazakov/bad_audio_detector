from __future__ import annotations

from .base import Depacketizer, EncodedFrame


class G729Depacketizer(Depacketizer):
    FRAME_BYTES = 10
    CN_BYTES = 2
    FRAME_SAMPLES = 80

    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        payload = packet.payload
        if not payload:
            return []
        if len(payload) % self.FRAME_BYTES == self.CN_BYTES:
            speech = payload[: -self.CN_BYTES]
            cn = payload[-self.CN_BYTES :]
        elif len(payload) % self.FRAME_BYTES == 0:
            speech = payload
            cn = b""
        else:
            raise ValueError("invalid G.729 payload length")

        frames: list[EncodedFrame] = []
        for index in range(len(speech) // self.FRAME_BYTES):
            frames.append(
                EncodedFrame(
                    codec=spec.encoding,
                    data=speech[index * 10 : (index + 1) * 10],
                    rtp_timestamp=(packet.timestamp + index * self.FRAME_SAMPLES)
                    & 0xFFFFFFFF,
                    duration=self.FRAME_SAMPLES,
                    sample_rate=spec.sample_rate,
                    sequence=packet.sequence,
                )
            )
        if cn:
            frames.append(
                EncodedFrame(
                    codec=spec.encoding,
                    data=b"",
                    rtp_timestamp=(packet.timestamp + len(frames) * self.FRAME_SAMPLES)
                    & 0xFFFFFFFF,
                    duration=self.FRAME_SAMPLES,
                    sample_rate=spec.sample_rate,
                    valid=False,
                    speech=False,
                    frame_type="cn",
                    sequence=packet.sequence,
                )
            )
        return frames
