from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class WindowScore(BaseModel):
    start_s: float
    end_s: float
    p_incorrect: float
    insufficient: bool


class AnalyzeResponse(BaseModel):
    verdict: Literal["correct_decoder", "incorrect_decoder"]
    confidence: float | None
    insufficient_signal: bool
    windows: list[WindowScore] = Field(default_factory=list)
    evidence: dict[str, float] = Field(default_factory=dict)
    model_version: str
    latency_ms: float
