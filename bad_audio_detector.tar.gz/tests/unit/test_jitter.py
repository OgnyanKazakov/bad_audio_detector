from __future__ import annotations

from bad_audio.io.rtp.header import RtpPacket
from bad_audio.io.rtp.jitter import JitterBuffer


def pkt(seq: int) -> RtpPacket:
    return RtpPacket(
        version=2,
        padding=False,
        extension=False,
        csrc_count=0,
        marker=False,
        payload_type=0,
        sequence=seq,
        timestamp=(seq * 160) & 0xFFFFFFFF,
        ssrc=1,
        payload=b"",
        payload_offset=12,
    )


def test_delivers_in_order_when_forced():
    jb = JitterBuffer(depth=2)
    jb.push(pkt(1))
    for seq in (3, 2, 4):
        jb.push(pkt(seq))
    out = jb.flush()
    assert [p.sequence for p in out] == [1, 2, 3, 4]
    assert jb.stats.lost == 0


def test_duplicate_is_counted_once():
    jb = JitterBuffer(depth=1)
    jb.push(pkt(1))
    jb.push(pkt(1))
    out = jb.flush()
    assert [p.sequence for p in out] == [1]
    assert jb.stats.duplicates == 1


def test_loss_advances_and_is_counted():
    jb = JitterBuffer(depth=1)
    jb.push(pkt(1))
    jb.push(pkt(2))
    jb.push(pkt(4))
    out = jb.flush()
    assert [p.sequence for p in out] == [1, 2, 4]
    assert jb.stats.lost == 1


def test_sequence_wrap():
    jb = JitterBuffer(depth=0)
    for seq in (65534, 65535, 0, 1):
        jb.push(pkt(seq))
    out = jb.flush()
    assert [p.sequence for p in out] == [65534, 65535, 0, 1]


def test_drain_waits_for_reorder_gap_unless_forced():
    jb = JitterBuffer(depth=2)
    jb.push(pkt(1))
    jb.push(pkt(3))
    assert jb.drain() == []
    jb.push(pkt(2))
    assert [p.sequence for p in jb.drain()] == [1, 2, 3]
