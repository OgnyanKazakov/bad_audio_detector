from __future__ import annotations

import numpy as np

from bad_audio.io.rtp.decoder import CodecDecoder, alaw_to_linear, ulaw_to_linear
from bad_audio.io.rtp.depacketizer import EncodedFrame, make_spec


def frame(data: bytes, *, codec="PCMU", duration=160, valid=True, rate=8000) -> EncodedFrame:
    return EncodedFrame(
        codec=codec,
        data=data,
        rtp_timestamp=0,
        duration=duration,
        sample_rate=rate,
        valid=valid,
    )


def test_ulaw_silence_and_alaw_silence():
    assert abs(float(ulaw_to_linear(np.array([0xFF], dtype=np.uint8))[0])) < 1e-3
    assert abs(float(alaw_to_linear(np.array([0xD5], dtype=np.uint8))[0])) < 1e-2


def test_g711_decode_and_invalid_gap():
    spec = make_spec("PCMU")
    decoded = CodecDecoder(target_rate=16000).decode(
        [frame(b"\xff" * 160), frame(b"", duration=160, valid=False)],
        spec,
    )
    assert decoded.pcm.dtype == np.float32
    assert decoded.pcm.shape == (640,)
    assert decoded.valid_mask[:320].all()
    assert not decoded.valid_mask[320:].any()


def test_amrnb_decode_roundtrip():
    import av

    sr = 8000
    t = np.arange(320) / sr
    pcm = (0.2 * np.sin(2 * np.pi * 440 * t) * 32767).astype(np.int16)
    enc = av.CodecContext.create("amr_nb", "w")
    enc.sample_rate = sr
    enc.layout = "mono"
    enc.format = "s16"
    af = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
    af.sample_rate = sr
    packets = enc.encode(af)
    data = b"".join(bytes(p) for p in packets)
    assert data
    decoded = CodecDecoder(target_rate=16000).decode(
        [frame(data, codec="AMR-NB", duration=160, rate=8000)],
        make_spec("AMR-NB"),
    )
    assert decoded.pcm.shape[0] >= 320
    assert decoded.valid_mask.any()
    assert float(np.max(np.abs(decoded.pcm))) > 0.01
