from __future__ import annotations


def decide(
    scores: list[float],
    threshold: float = 0.5,
    consecutive: int = 2,
    insufficient: bool = False,
) -> str:
    if insufficient or not scores:
        return "correct_decoder"
    need = max(1, int(consecutive))
    run = 0
    for score in scores:
        if score >= threshold:
            run += 1
            if run >= need:
                return "incorrect_decoder"
        else:
            run = 0
    if len(scores) < need and max(scores) >= threshold:
        return "incorrect_decoder"
    return "correct_decoder"
