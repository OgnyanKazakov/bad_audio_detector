from __future__ import annotations

import numpy as np
from sklearn.linear_model import LogisticRegression

from bad_audio.detect.model import load_model, save_model
from bad_audio.dsp.features import FEATURE_NAMES, extract_features, feature_vector
from bad_audio.pipeline import Detector


def tone(seconds=1.0):
    t = np.arange(int(16000 * seconds)) / 16000
    return (0.2 * np.sin(2 * np.pi * 440 * t)).astype(np.float32)


def test_model_artifact_roundtrip(tmp_path):
    rng = np.random.default_rng(3)
    good = [extract_features(tone()) for _ in range(3)]
    bad = [extract_features((0.2 * rng.standard_normal(16000)).astype(np.float32)) for _ in range(3)]
    X = np.asarray([feature_vector(f) for f in good + bad], dtype=np.float32)
    y = np.asarray([0, 0, 0, 1, 1, 1])
    clf = LogisticRegression(max_iter=1000).fit(X, y)
    path = tmp_path / "detector.joblib"
    save_model(str(path), clf, FEATURE_NAMES, threshold=0.5, version="test")
    loaded = load_model(str(path))
    assert loaded is not None
    assert loaded.version == "test"
    result = Detector(model=loaded).analyze_pcm(tone(2.0))
    assert result.verdict == "correct_decoder"
