from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .framing import frame_signal

DTMF_FREQS = (697, 770, 852, 941, 1209, 1336, 1477, 1633)
DTMF_DIGITS = {
    (697, 1209): "1",
    (697, 1336): "2",
    (697, 1477): "3",
    (697, 1633): "A",
    (770, 1209): "4",
    (770, 1336): "5",
    (770, 1477): "6",
    (770, 1633): "B",
    (852, 1209): "7",
    (852, 1336): "8",
    (852, 1477): "9",
    (852, 1633): "C",
    (941, 1209): "*",
    (941, 1336): "0",
    (941, 1477): "#",
    (941, 1633): "D",
}


@dataclass(frozen=True, slots=True)
class DTMFEvent:
    start_s: float
    end_s: float
    digit: str


def _tone_magnitudes(frame: np.ndarray, sample_rate: int) -> dict[int, float]:
    n = frame.size
    t = np.arange(n, dtype=np.float32)
    out = {}
    for freq in DTMF_FREQS:
        basis = np.exp(-2j * np.pi * freq * t / sample_rate)
        out[freq] = float(abs(np.dot(frame, basis)) / n)
    return out


def detect_dtmf(x: np.ndarray, sample_rate: int = 16000) -> list[DTMFEvent]:
    frame_size = int(0.02 * sample_rate)
    hop = int(0.01 * sample_rate)
    frames = frame_signal(x, frame_size, hop)
    if frames.size == 0:
        return []
    labels: list[str | None] = []
    for frame in frames:
        level = float(np.sqrt(np.mean(frame**2) + 1e-12))
        if level < 0.01:
            labels.append(None)
            continue
        mags = _tone_magnitudes(frame, sample_rate)
        found: str | None = None
        for low in DTMF_FREQS[:4]:
            for high in DTMF_FREQS[4:]:
                a, b = mags[low], mags[high]
                if a > 0.03 and b > 0.03 and a > 0.35 * level and b > 0.35 * level:
                    found = DTMF_DIGITS[(low, high)]
                    break
            if found:
                break
        labels.append(found)

    events: list[DTMFEvent] = []
    start: int | None = None
    current: str | None = None
    last: int | None = None
    for index, label in enumerate(labels + [None]):
        if label != current:
            if current is not None and start is not None and last is not None:
                events.append(
                    DTMFEvent(
                        start_s=start * hop / sample_rate,
                        end_s=(last + 1) * frame_size / sample_rate,
                        digit=current,
                    )
                )
            start = index if label is not None else None
            current = label
        last = index if label is not None else last
    return events


def dtmf_mask(x: np.ndarray, sample_rate: int = 16000, hop: int = 160) -> np.ndarray:
    events = detect_dtmf(x, sample_rate)
    n = max(1, int(np.ceil(len(x) / hop)))
    mask = np.zeros(n, dtype=bool)
    for event in events:
        a = int(event.start_s * sample_rate) // hop
        b = int(event.end_s * sample_rate) // hop
        mask[max(0, a) : min(n, b + 1)] = True
    return mask
