from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import av
import numpy as np
from scipy.signal import lfilter, resample_poly

SR = 16000


def _resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out:
        return x.astype(np.float32)
    g = math.gcd(sr_in, sr_out)
    return resample_poly(x, sr_out // g, sr_in // g).astype(np.float32)


def synth_speech(seconds: float = 3.0, sr: int = SR, seed: int = 0) -> np.ndarray:
    """Formant-synthesized speech-like audio for demos and tests."""
    rng = np.random.default_rng(seed)
    n = int(seconds * sr)
    t = np.arange(n) / sr

    f0 = 120.0 + 25.0 * np.sin(2 * np.pi * 0.4 * t + rng.uniform(0, 6.28))
    f0 += 8.0 * np.sin(2 * np.pi * 1.7 * t + rng.uniform(0, 6.28))
    phase = 2 * np.pi * np.cumsum(f0) / sr
    source = np.zeros(n, dtype=np.float64)
    for harmonic in range(1, 24):
        if harmonic * 130 < sr / 2:
            source += np.sin(harmonic * phase) / harmonic
    source = source / (np.max(np.abs(source)) + 1e-9)

    # Alternate voiced and unvoiced segments.
    voiced = (np.sin(2 * np.pi * 1.3 * t + rng.uniform(0, 6.28)) > -0.2).astype(float)
    noise = rng.standard_normal(n)
    source = source * voiced + 0.15 * noise * (1 - voiced)

    y = np.zeros(n, dtype=np.float64)
    for fc, bw, gain in ((700, 90, 1.0), (1220, 110, 0.7), (2600, 160, 0.4)):
        r = math.exp(-math.pi * bw / sr)
        theta = 2 * math.pi * fc / sr
        b = [1 - r]
        a = [1, -2 * r * math.cos(theta), r * r]
        y += gain * lfilter(b, a, source)

    syllable = 0.55 + 0.45 * np.sin(2 * np.pi * 4.0 * t + rng.uniform(0, 6.28)) ** 2
    gate = np.ones(n)
    for _ in range(max(1, int(seconds / 1.5))):
        start = int(rng.uniform(0, max(0.01, seconds - 0.35)) * sr)
        gate[start : start + int(0.25 * sr)] = 0.05
    y = y * syllable * gate
    y = y / (np.max(np.abs(y)) + 1e-9) * 0.35
    return y.astype(np.float32)


def add_tones(x: np.ndarray, sr: int = SR, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed + 1)
    x = x.copy()
    mode = int(rng.integers(0, 3))
    n = len(x)
    if mode == 0:
        return x
    length = min(n, int(0.35 * sr))
    start = int(rng.integers(0, max(1, n - length)))
    t = np.arange(length) / sr
    if mode == 1:
        tone = 0.2 * np.sin(2 * np.pi * 440 * t) + 0.2 * np.sin(2 * np.pi * 480 * t)
    else:
        low, high = (697, 1209) if rng.random() < 0.5 else (852, 1477)
        tone = 0.22 * np.sin(2 * np.pi * low * t) + 0.22 * np.sin(2 * np.pi * high * t)
    x[start : start + length] = x[start : start + length] * 0.1 + tone.astype(np.float32)
    return x


def add_noise(x: np.ndarray, snr_db: float, seed: int = 0) -> np.ndarray:
    if snr_db >= 60:
        return x.copy()
    rng = np.random.default_rng(seed + 2)
    signal_power = float(np.mean(x**2) + 1e-12)
    noise = rng.standard_normal(len(x)).astype(np.float32)
    noise_power = float(np.mean(noise**2))
    scale = math.sqrt(signal_power / (10 ** (snr_db / 10) * noise_power))
    return (x + scale * noise).astype(np.float32)


def simulate_packet_loss(x: np.ndarray, fraction: float, sr: int = SR, seed: int = 0) -> np.ndarray:
    if fraction <= 0:
        return x.copy()
    rng = np.random.default_rng(seed + 3)
    y = x.copy()
    block = max(1, int(0.02 * sr))
    for start in range(0, len(y), block):
        if rng.random() < fraction:
            y[start : start + block] = 0.0
    return y


def pad_silence(x: np.ndarray, seed: int = 0, max_seconds: float = 0.8) -> np.ndarray:
    rng = np.random.default_rng(seed + 23)
    pre = int(rng.uniform(0.0, max_seconds) * SR)
    post = int(rng.uniform(0.0, max_seconds) * SR)
    return np.concatenate(
        [np.zeros(pre, dtype=np.float32), x.astype(np.float32), np.zeros(post, dtype=np.float32)]
    )


def tone_source(seconds: float = 3.0, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed + 31)
    sr = SR
    n = int(seconds * sr)
    t = np.arange(n) / sr
    x = np.zeros(n, dtype=np.float32)
    start = int(0.4 * sr)
    length = int(0.9 * sr)
    seg = t[start : start + length]
    if rng.random() < 0.5:
        tone = 0.25 * np.sin(2 * np.pi * 440 * seg) + 0.25 * np.sin(2 * np.pi * 480 * seg)
    else:
        low, high = (697, 1209) if rng.random() < 0.5 else (852, 1477)
        tone = 0.25 * np.sin(2 * np.pi * low * seg) + 0.25 * np.sin(2 * np.pi * high * seg)
    end = min(n, start + length)
    x[start:end] = tone[: end - start]
    return x


def continuous_tone(seconds: float = 3.0, seed: int = 0) -> np.ndarray:
    """Continuous DTMF/ringback-like tone sequence, a valid call signal."""
    rng = np.random.default_rng(seed + 41)
    sr = SR
    n = int(seconds * sr)
    x = np.zeros(n, dtype=np.float32)
    if rng.random() < 0.4:
        t = np.arange(n) / sr
        x = (0.22 * np.sin(2 * np.pi * 440 * t) + 0.22 * np.sin(2 * np.pi * 480 * t)).astype(np.float32)
        return x
    pairs = [(697, 1209), (770, 1336), (852, 1477), (941, 1633)]
    segment = int(0.45 * sr)
    for start in range(0, n, segment):
        low, high = pairs[int(rng.integers(0, len(pairs)))]
        end = min(n, start + segment)
        t = np.arange(end - start) / sr
        x[start:end] = (
            0.22 * np.sin(2 * np.pi * low * t) + 0.22 * np.sin(2 * np.pi * high * t)
        ).astype(np.float32)
    return x


def continuous_single_tone(seconds: float = 3.0, seed: int = 0, fixed: bool = False) -> np.ndarray:
    rng = np.random.default_rng(seed + 47)
    sr = SR
    t = np.arange(int(seconds * sr)) / sr
    if fixed:
        return (0.2 * np.sin(2 * np.pi * 1000 * t)).astype(np.float32)
    pairs = [(697, 1209), (770, 1336), (852, 1477), (941, 1633), (440, 480)]
    low, high = pairs[int(rng.integers(0, len(pairs)))]
    return (
        0.2 * np.sin(2 * np.pi * low * t) + 0.2 * np.sin(2 * np.pi * high * t)
    ).astype(np.float32)


@dataclass
class CodecResult:
    pcm: np.ndarray
    encoded: bytes


def _encode_with_av(x: np.ndarray, sr: int, codec: str, bitrate: int | None = None) -> bytes:
    enc = av.CodecContext.create(codec, "w")
    enc.sample_rate = sr
    enc.layout = "mono"
    enc.format = "s16"
    if bitrate:
        enc.bit_rate = bitrate
    pcm = np.clip(x, -1.0, 1.0)
    pcm_i16 = (pcm * 32767).astype(np.int16)
    frame = av.AudioFrame.from_ndarray(pcm_i16.reshape(1, -1), format="s16", layout="mono")
    frame.sample_rate = sr
    packets = enc.encode(frame)
    packets += enc.encode(None)
    return b"".join(bytes(p) for p in packets)


def _decode_with_av(data: bytes, sr: int, codec: str, target_sr: int = SR) -> np.ndarray:
    dec = av.CodecContext.create(codec, "r")
    try:
        dec.sample_rate = sr
        dec.layout = "mono"
    except Exception:
        pass
    resampler = av.AudioResampler(format="flt", layout="mono", rate=target_sr)
    chunks: list[np.ndarray] = []
    try:
        for frame in dec.decode(av.Packet(data)):
            for out in resampler.resample(frame):
                chunks.append(out.to_ndarray().reshape(-1))
    except Exception:
        pass
    try:
        for frame in dec.decode(None):
            for out in resampler.resample(frame):
                chunks.append(out.to_ndarray().reshape(-1))
    except Exception:
        pass
    try:
        for out in resampler.resample(None):
            chunks.append(out.to_ndarray().reshape(-1))
    except Exception:
        pass
    if not chunks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(chunks).astype(np.float32)


CODECS: dict[str, tuple[int, str, str, int | None]] = {
    "PCMU": (8000, "pcm_mulaw", "pcm_mulaw", None),
    "PCMA": (8000, "pcm_alaw", "pcm_alaw", None),
    "G722": (16000, "g722", "g722", None),
    "AMR-NB": (8000, "amr_nb", "amrnb", 12200),
    "OPUS": (16000, "libopus", "opus", 16000),
    "MP3": (16000, "libmp3lame", "mp3", 64000),
}


def correct_roundtrip(x: np.ndarray, codec: str) -> np.ndarray:
    sr, enc_name, dec_name, bitrate = CODECS[codec]
    pcm = _resample(x, SR, sr)
    data = _encode_with_av(pcm, sr, enc_name, bitrate)
    if not data:
        return x.copy()
    out = _decode_with_av(data, sr, dec_name)
    return _resample(out, SR, SR) if out.size else x.copy()


def _scramble(data: bytes, seed: int) -> bytes:
    rng = np.random.default_rng(seed + 17)
    order = rng.permutation(len(data))
    return bytes(data[i] for i in order)


def corrupt_wrong_decoder(x: np.ndarray, codec: str, seed: int = 0) -> np.ndarray:
    """Encode with one codec, then decode the bytes as a different waveform codec."""
    sr, enc_name, _, bitrate = CODECS[codec]
    pcm = _resample(x, SR, sr)
    data = _encode_with_av(pcm, sr, enc_name, bitrate)
    if not data:
        return x.copy()
    from bad_audio.io.rtp.decoder import ulaw_to_linear

    scrambled = _scramble(data, seed)
    raw = np.frombuffer(scrambled, dtype=np.uint8)
    noise = ulaw_to_linear(raw)
    if noise.size == 0:
        return x.copy()

    # Keep a call-like energy envelope so the corruption is realistic.
    from scipy.ndimage import uniform_filter1d

    env = uniform_filter1d(np.abs(x).astype(np.float32), size=max(1, int(0.02 * SR)))
    env = env / (float(np.max(env)) + 1e-9)
    if env.size != noise.size:
        env = np.interp(
            np.linspace(0.0, 1.0, noise.size),
            np.linspace(0.0, 1.0, env.size),
            env,
        ).astype(np.float32)
    noise = noise / (float(np.sqrt(np.mean(noise**2))) + 1e-9) * 0.25
    out = (noise * (0.2 + 0.8 * env)).astype(np.float32)
    out = _resample(out, sr, SR)
    if out.size < len(x):
        out = np.pad(out, (0, len(x) - out.size))
    return out[: len(x)].astype(np.float32)


def save_wav(path: str | Path, x: np.ndarray, sr: int = SR) -> None:
    import soundfile as sf

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), np.asarray(x, dtype=np.float32), sr)


def save_mp3(path: str | Path, x: np.ndarray, sr: int = SR, bitrate: int = 128000) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    container = av.open(str(path), mode="w", format="mp3")
    stream = container.add_stream("libmp3lame", rate=sr)
    stream.layout = "mono"
    stream.bit_rate = bitrate
    pcm = (np.clip(x, -1.0, 1.0) * 32767).astype(np.int16)
    frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
    frame.sample_rate = sr
    for packet in stream.encode(frame):
        container.mux(packet)
    for packet in stream.encode(None):
        container.mux(packet)
    container.close()


def make_good(
    x: np.ndarray,
    codec: str,
    snr_db: float,
    loss: float,
    seed: int,
    extra_tones: bool = True,
) -> np.ndarray:
    y = add_tones(x, seed=seed) if extra_tones else x.copy()
    y = add_noise(y, snr_db, seed=seed)
    y = simulate_packet_loss(y, loss, seed=seed)
    return correct_roundtrip(y, codec)


def make_bad(x: np.ndarray, codec: str, seed: int) -> np.ndarray:
    return corrupt_wrong_decoder(x, codec, seed=seed)
