from __future__ import annotations

import numpy as np

from bad_audio.detect.decision import decide
from bad_audio.detect.rules import rules_score
from bad_audio.dsp.features import extract_features


def sine(sr: int, seconds: float, freq: float = 440.0, amp: float = 0.2) -> np.ndarray:
    t = np.arange(int(sr * seconds)) / sr
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_decision_requires_consecutive_windows():
    verdict = decide([0.9, 0.9, 0.1], threshold=0.5, consecutive=2)
    assert verdict == "incorrect_decoder"
    verdict = decide([0.9, 0.1, 0.9], threshold=0.5, consecutive=2)
    assert verdict == "correct_decoder"
    verdict = decide([0.9], threshold=0.5, consecutive=2)
    assert verdict == "incorrect_decoder"


def test_insufficient_signal_is_correct():
    verdict = decide([], threshold=0.5, consecutive=2, insufficient=True)
    assert verdict == "correct_decoder"


def test_rules_score_separates_tone_noise_and_silence():
    rng = np.random.default_rng(1)
    tone = extract_features(sine(16000, 1.0))
    noise = extract_features((0.2 * rng.standard_normal(16000)).astype(np.float32))
    silence = extract_features(np.zeros(16000, dtype=np.float32))
    assert rules_score(tone) < 0.4
    assert rules_score(noise) > 0.7
    assert silence["insufficient_signal"] == 1.0
