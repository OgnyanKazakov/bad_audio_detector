from __future__ import annotations

import io
import math

import av
import numpy as np
from scipy.signal import resample_poly

TARGET_RATE = 16000


def resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    if sr_in == sr_out or x.size == 0:
        return x
    g = math.gcd(int(sr_in), int(sr_out))
    return resample_poly(x, sr_out // g, sr_in // g).astype(np.float32)


def to_mono(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if x.ndim == 1:
        return x
    if x.ndim == 2:
        return x.mean(axis=0, dtype=np.float32)
    return x.reshape(-1)


def decode_audio_bytes(data: bytes, filename: str | None = None) -> np.ndarray:
    """Decode any PyAV-supported audio container to 16 kHz mono float32."""
    if not data:
        return np.zeros(0, dtype=np.float32)
    try:
        container = av.open(io.BytesIO(data))
    except Exception as exc:
        raise ValueError(f"cannot open audio{': ' + filename if filename else ''}") from exc
    with container:
        stream = next((s for s in container.streams if s.type == "audio"), None)
        if stream is None:
            raise ValueError("no audio stream")
        resampler = av.AudioResampler(format="flt", layout="mono", rate=TARGET_RATE)
        chunks: list[np.ndarray] = []
        for frame in container.decode(stream):
            for out in resampler.resample(frame):
                chunks.append(out.to_ndarray().reshape(-1))
        for out in resampler.resample(None):
            chunks.append(out.to_ndarray().reshape(-1))
    if not chunks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(chunks).astype(np.float32, copy=False)


def read_pcm(data: bytes, sample_rate: int, fmt: str = "s16le") -> np.ndarray:
    fmt = fmt.lower()
    if fmt == "s16le":
        x = np.frombuffer(data, dtype="<i2").astype(np.float32) / 32768.0
    elif fmt == "s16be":
        x = np.frombuffer(data, dtype=">i2").astype(np.float32) / 32768.0
    elif fmt == "f32le":
        x = np.frombuffer(data, dtype="<f4").astype(np.float32)
    elif fmt == "f32be":
        x = np.frombuffer(data, dtype=">f4").astype(np.float32)
    else:
        raise ValueError(f"unsupported PCM format {fmt}")
    return resample(x, sample_rate, TARGET_RATE)


def write_wav(path: str, x: np.ndarray, sample_rate: int = TARGET_RATE) -> None:
    import soundfile as sf

    sf.write(path, np.asarray(x, dtype=np.float32), sample_rate)
