from __future__ import annotations

from ..specs import CodecSpec, make_spec, normalize_encoding
from .amr import AmrDepacketizer
from .base import Depacketizer, EncodedFrame
from .cn import CN_Depacketizer
from .g711 import G711Depacketizer
from .g722 import G722Depacketizer
from .g729 import G729Depacketizer
from .ilbc import ILBCDepacketizer
from .l16 import L16Depacketizer
from .opus import OpusDepacketizer


def _make(encoding: str) -> Depacketizer:
    if encoding in ("PCMU", "PCMA"):
        return G711Depacketizer()
    if encoding == "G722":
        return G722Depacketizer()
    if encoding == "G729":
        return G729Depacketizer()
    if encoding == "AMR-NB":
        return AmrDepacketizer(wideband=False)
    if encoding == "AMR-WB":
        return AmrDepacketizer(wideband=True)
    if encoding == "OPUS":
        return OpusDepacketizer()
    if encoding == "ILBC":
        return ILBCDepacketizer()
    if encoding == "L16":
        return L16Depacketizer()
    if encoding == "CN":
        return CN_Depacketizer()
    raise ValueError(f"no depacketizer for {encoding}")


_CACHE: dict[str, Depacketizer] = {}


def get_depacketizer(spec: CodecSpec) -> Depacketizer:
    if spec.encoding not in _CACHE:
        _CACHE[spec.encoding] = _make(spec.encoding)
    return _CACHE[spec.encoding]


def depacketize(packet, spec: CodecSpec) -> list[EncodedFrame]:
    return get_depacketizer(spec).depacketize(packet, spec)


__all__ = [
    "CodecSpec",
    "Depacketizer",
    "EncodedFrame",
    "depacketize",
    "get_depacketizer",
    "make_spec",
    "normalize_encoding",
]
