from __future__ import annotations

import numpy as np
from scipy.linalg import solve_toeplitz

from .framing import frame_signal
from .vad import rms, vad_mask

EPS = 1e-10
FRAME_SIZE = 512
HOP_SIZE = 160
SAMPLE_RATE = 16000
BANDS = ((300, 1000), (1000, 2000), (2000, 4000), (4000, 6000), (6000, 8000))
STATS = ("mean", "std", "p10", "p50", "p90")
BASE_FEATURES = (
    "flatness",
    "centroid",
    "spread",
    "rolloff",
    "entropy",
    "crest",
    "flux",
    "zcr",
    "hnr",
    "voicing",
    "f0",
    "lpc_error",
    "band1",
    "band2",
    "band3",
    "band4",
    "band5",
    "holes",
    "rolloff_norm",
)
EXTRA_FEATURES = (
    "active_fraction",
    "voiced_fraction",
    "pitch_jitter",
    "modulation_2_8",
    "gap_fraction",
    "insufficient_signal",
)


def feature_names() -> list[str]:
    names = [f"{name}_{stat}" for name in BASE_FEATURES for stat in STATS]
    names.extend(EXTRA_FEATURES)
    return names


FEATURE_NAMES = feature_names()


def _neutral_features() -> dict[str, float]:
    return {name: 0.0 for name in FEATURE_NAMES}


def _autocorr_features(frames: np.ndarray, sample_rate: int) -> tuple[np.ndarray, ...]:
    n = frames.shape[1]
    window = np.hanning(n).astype(np.float32)
    spec = np.fft.rfft(frames * window, axis=1)
    ac = np.fft.irfft(np.abs(spec) ** 2, n=n, axis=1)
    ac = ac / (ac[:, :1] + EPS)
    min_lag = max(1, int(sample_rate / 400))
    max_lag = min(n - 2, int(sample_rate / 60))
    if max_lag <= min_lag:
        zeros = np.zeros(frames.shape[0], dtype=np.float32)
        return zeros, zeros, zeros, zeros
    segment = ac[:, min_lag : max_lag + 1]
    peak_offsets = np.argmax(segment, axis=1)
    peak_lags = peak_offsets + min_lag
    voicing = segment[np.arange(len(segment)), peak_offsets]
    voicing = np.clip(voicing, 0.0, 0.999)
    hnr = 10.0 * np.log10(voicing / (1.0 - voicing + EPS) + EPS)
    f0 = np.where(voicing > 0.2, sample_rate / peak_lags, 0.0).astype(np.float32)

    order = 10
    lpc_error = np.zeros(frames.shape[0], dtype=np.float32)
    for i in range(frames.shape[0]):
        r = ac[i, : order + 1]
        try:
            a = solve_toeplitz((r[:-1], r[:-1]), r[1:])
            err = float(r[0] - np.dot(a, r[1:]))
            lpc_error[i] = max(0.0, err) / (float(r[0]) + EPS)
        except Exception:
            lpc_error[i] = 1.0
    return hnr.astype(np.float32), voicing.astype(np.float32), f0, lpc_error


def frame_features(frames: np.ndarray, sample_rate: int = SAMPLE_RATE) -> dict[str, np.ndarray]:
    frames = np.asarray(frames, dtype=np.float32)
    if frames.ndim != 2 or frames.shape[0] == 0:
        return {name: np.zeros(0, dtype=np.float32) for name in BASE_FEATURES}
    n_fft = frames.shape[1]
    window = np.hamming(n_fft).astype(np.float32)
    spec = np.abs(np.fft.rfft(frames * window, axis=1))
    power = spec**2 + EPS
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sample_rate)
    total = power.sum(axis=1) + EPS
    p = power / total[:, None]

    flatness = np.exp(np.mean(np.log(power), axis=1)) / (np.mean(power, axis=1) + EPS)
    centroid = (p * freqs[None, :]).sum(axis=1)
    spread = np.sqrt((p * (freqs[None, :] - centroid[:, None]) ** 2).sum(axis=1))
    cumulative = np.cumsum(p, axis=1)
    rolloff = freqs[np.argmax(cumulative >= 0.85, axis=1)]
    entropy = -(p * np.log(p + EPS)).sum(axis=1) / np.log(power.shape[1])
    crest = spec.max(axis=1) / (spec.mean(axis=1) + EPS)

    norm_spec = spec / (spec.sum(axis=1, keepdims=True) + EPS)
    flux = np.zeros(frames.shape[0], dtype=np.float32)
    if frames.shape[0] > 1:
        flux[1:] = np.sqrt(np.sum(np.diff(norm_spec, axis=0) ** 2, axis=1))
    zcr = np.mean(np.abs(np.diff(np.signbit(frames).astype(np.int8), axis=1)), axis=1)

    bands = []
    for low, high in BANDS:
        mask = (freqs >= low) & (freqs < high)
        bands.append(p[:, mask].sum(axis=1) if mask.any() else np.zeros(frames.shape[0]))

    max_power = power.max(axis=1, keepdims=True)
    holes = np.mean(power < max_power * 1e-4, axis=1)
    rolloff_norm = rolloff / (sample_rate / 2.0)

    hnr, voicing, f0, lpc_error = _autocorr_features(frames, sample_rate)

    out = {
        "flatness": flatness,
        "centroid": centroid,
        "spread": spread,
        "rolloff": rolloff,
        "entropy": entropy,
        "crest": crest,
        "flux": flux,
        "zcr": zcr,
        "hnr": hnr,
        "voicing": voicing,
        "f0": f0,
        "lpc_error": lpc_error,
        "holes": holes,
        "rolloff_norm": rolloff_norm,
    }
    for index, values in enumerate(bands, start=1):
        out[f"band{index}"] = values
    return {name: np.asarray(values, dtype=np.float32) for name, values in out.items()}


def _frame_validity(n_frames: int, valid_mask: np.ndarray | None, frame_size: int, hop: int) -> np.ndarray:
    if valid_mask is None:
        return np.ones(n_frames, dtype=bool)
    valid = np.asarray(valid_mask, dtype=bool)
    out = np.zeros(n_frames, dtype=bool)
    for i in range(n_frames):
        start = i * hop
        piece = valid[start : start + frame_size]
        out[i] = piece.size > 0 and float(piece.mean()) > 0.5
    return out


def _aggregate(
    feats: dict[str, np.ndarray],
    active: np.ndarray,
    valid_frames: np.ndarray,
    sample_rate: int,
    hop: int,
) -> dict[str, float]:
    result = _neutral_features()
    if not active.any():
        return result
    for name in BASE_FEATURES:
        values = feats[name][active]
        if values.size == 0:
            continue
        result[f"{name}_mean"] = float(np.mean(values))
        result[f"{name}_std"] = float(np.std(values))
        result[f"{name}_p10"] = float(np.percentile(values, 10))
        result[f"{name}_p50"] = float(np.percentile(values, 50))
        result[f"{name}_p90"] = float(np.percentile(values, 90))

    result["active_fraction"] = float(active.mean())
    voiced = (feats["voicing"][active] > 0.3) & (feats["f0"][active] > 0)
    result["voiced_fraction"] = float(voiced.mean()) if voiced.size else 0.0
    f0 = feats["f0"][active]
    f0 = f0[f0 > 0]
    if f0.size >= 2:
        result["pitch_jitter"] = float(np.median(np.abs(np.diff(f0))) / (np.median(f0) + EPS))
    else:
        result["pitch_jitter"] = 0.0

    return result


def extract_features(
    pcm: np.ndarray,
    valid_mask: np.ndarray | None = None,
    sample_rate: int = SAMPLE_RATE,
    min_active_seconds: float = 0.3,
    vad_threshold: float = 0.01,
) -> dict[str, float]:
    pcm = np.asarray(pcm, dtype=np.float32).reshape(-1)
    neutral = _neutral_features()
    if pcm.size < int(0.2 * sample_rate):
        neutral["insufficient_signal"] = 1.0
        return neutral

    frames = frame_signal(pcm, FRAME_SIZE, HOP_SIZE)
    if frames.size == 0:
        neutral["insufficient_signal"] = 1.0
        return neutral

    valid_frames = _frame_validity(
        frames.shape[0], valid_mask, FRAME_SIZE, HOP_SIZE
    )
    if valid_frames.sum() == 0:
        neutral["insufficient_signal"] = 1.0
        return neutral

    active = vad_mask(frames, sample_rate, threshold=vad_threshold) & valid_frames
    min_frames = max(1, int(min_active_seconds * sample_rate / HOP_SIZE))
    if active.sum() < min_frames:
        neutral["active_fraction"] = float(active.mean())
        neutral["gap_fraction"] = float(1.0 - valid_frames.mean())
        neutral["insufficient_signal"] = 1.0
        return neutral

    feats = frame_features(frames, sample_rate)
    result = _aggregate(feats, active, valid_frames, sample_rate, HOP_SIZE)
    result["gap_fraction"] = float(1.0 - valid_frames.mean())
    result["insufficient_signal"] = 0.0

    # Envelope modulation in the syllabic 2-8 Hz band.
    envelope = rms(frames)[valid_frames]
    if envelope.size >= 10:
        envelope = envelope - float(np.mean(envelope))
        spectrum = np.abs(np.fft.rfft(envelope)) ** 2
        freqs = np.fft.rfftfreq(envelope.size, HOP_SIZE / sample_rate)
        band = (freqs >= 2.0) & (freqs <= 8.0)
        result["modulation_2_8"] = float(spectrum[band].sum() / (spectrum.sum() + EPS))
    else:
        result["modulation_2_8"] = 0.0

    return {name: float(np.nan_to_num(result.get(name, 0.0), nan=0.0, posinf=0.0, neginf=0.0))
            for name in FEATURE_NAMES}


def feature_vector(features: dict[str, float]) -> np.ndarray:
    return np.asarray([float(features.get(name, 0.0)) for name in FEATURE_NAMES], dtype=np.float32)
