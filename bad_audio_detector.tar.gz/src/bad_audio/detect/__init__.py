"""Detection pipeline and classifiers."""
