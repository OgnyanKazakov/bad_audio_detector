# Bad Audio Detector Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans. Steps use checkbox syntax.

**Goal:** Build a codec-agnostic MP3/RTP call-audio corruption detector with a FastAPI service and offline MP3 retraining workflow.

**Architecture:** MP3/RTP ingress -> decode/depacketize -> 16 kHz PCM -> codec-robust spectral/speech features -> window aggregation -> HistGradientBoosting classifier -> smoothed binary verdict. RTP codecs are pluggable through a registry; AMR supports multiframe BE/OA.

**Tech Stack:** Python 3.10, FastAPI, pydantic-settings, numpy, scipy, scikit-learn, PyAV, joblib, pytest. Docker image includes FFmpeg/AMR libraries.

**Spec:** `docs/superpowers/specs/2026-10-21-bad-audio-detector-design.md`

## Global Constraints

- Internal audio: mono float32, 16000 Hz.
- Verdict strings: `correct_decoder`, `incorrect_decoder`.
- `insufficient_signal` is response metadata, not a verdict.
- MP3-only labeled folders; RTP only in production ingress.
- No production code without a failing test first.
- No raw audio logging.

---

### Task 1: Scaffold and config

**Files:** `pyproject.toml`, `.env.example`, `Dockerfile`, `src/bad_audio/__init__.py`, `src/bad_audio/config.py`, `tests/unit/test_config.py`

**Interfaces:** `Settings` with `app_mode`, `window_seconds`, `hop_seconds`, `decision_threshold`, `model_path`, `good_records_dir`, `bad_records_dir`; `get_settings()`.

- [ ] Write test that env vars populate `Settings` and defaults are correct.
- [ ] Run test; expect import failure.
- [ ] Implement config and packaging; run test.
- [ ] Commit.

### Task 2: RTP header + jitter buffer

**Files:** `src/bad_audio/io/rtp/header.py`, `jitter.py`, `tests/unit/test_rtp_header.py`, `tests/unit/test_jitter.py`

**Interfaces:** `RtpPacket`, `parse_rtp(bytes) -> RtpPacket`; `JitterBuffer.push(packet) -> list[RtpPacket]`, `flush() -> list[RtpPacket]`.

- [ ] Write tests for base header, CSRC, extension, padding, sequence wrap, reorder, duplicate, loss.
- [ ] Run tests; expect failure.
- [ ] Implement parser/jitter; run tests.
- [ ] Commit.

### Task 3: Codec specs, SDP, and depacketizers

**Files:** `src/bad_audio/io/rtp/specs.py`, `sdp.py`, `depacketizer/*.py`, `tests/unit/test_depacketizers.py`

**Interfaces:** `CodecSpec`, `EncodedFrame`, `depacketize(packet, spec) -> list[EncodedFrame]`; registry for PCMU, PCMA, G722, G729, AMR-NB, AMR-WB, Opus, iLBC, L16, CN.

- [ ] Write tests for G.711, G.722 clock, G.729 multiframe/CN, AMR BE single/multi, AMR OA single/multi, Opus duration, L16.
- [ ] Run tests; expect failure.
- [ ] Implement specs, SDP parser, depacketizers; run tests.
- [ ] Commit.

### Task 4: Audio decode/resample and codec decoder

**Files:** `src/bad_audio/io/audio.py`, `io/rtp/decoder.py`, `tests/unit/test_audio.py`, `tests/unit/test_codec_decoder.py`

**Interfaces:** `decode_audio_bytes(data, filename) -> np.ndarray`; `resample(x, sr_in, sr_out)`; `CodecDecoder.decode(frames) -> (pcm, valid_mask)`.

- [ ] Write tests for WAV/MP3 decode (skip MP3 if unavailable), resampling length/rate, AMR header reconstruction, G.711 decode.
- [ ] Run tests; expect failure.
- [ ] Implement; run tests.
- [ ] Commit.

### Task 5: DSP features, VAD, DTMF

**Files:** `src/bad_audio/dsp/framing.py`, `vad.py`, `tones.py`, `features.py`, `aggregate.py`, `tests/unit/test_dsp.py`

**Interfaces:** `frame_signal`, `vad_mask`, `detect_dtmf`, `frame_features`, `aggregate_windows`.

- [ ] Write tests for frame count, silence VAD, tone detection, feature shape/determinism, window aggregation.
- [ ] Run tests; expect failure.
- [ ] Implement; run tests.
- [ ] Commit.

### Task 6: Rules, model, decision, pipeline

**Files:** `src/bad_audio/detect/rules.py`, `model.py`, `decision.py`, `pipeline.py`, `tests/unit/test_decision.py`, `tests/integration/test_pipeline.py`

**Interfaces:** `score_windows(features) -> np.ndarray`; `Detector.score(pcm) -> AnalysisResult`; `smoothed_verdict`.

- [ ] Write tests for hysteresis, insufficient signal, pipeline on tone/silence, model round-trip.
- [ ] Run tests; expect failure.
- [ ] Implement; run tests.
- [ ] Commit.

### Task 7: Synthetic generation, training, evaluation

**Files:** `scripts/generate_dataset.py`, `train.py`, `evaluate.py`, `src/bad_audio/data/synthetic.py`, `tests/unit/test_synthetic.py`

- [ ] Write tests for codec round-trip labels/manifest and feature extraction.
- [ ] Implement generator/training/eval; run tests.
- [ ] Commit.

### Task 8: API (HTTP + WebSocket)

**Files:** `src/bad_audio/api/*.py`, `tests/integration/test_api.py`

- [ ] Write tests for `/healthz`, `/v1/analyze` with WAV/MP3, WS PCM streaming, error cases.
- [ ] Implement; run tests.
- [ ] Commit.

### Task 9: MP3 good/bad folder tooling

**Files:** `src/bad_audio/data/labeled_dirs.py`, `scripts/calibrate_threshold.py`, `retrain_from_dirs.py`, `tests/unit/test_labeled_dirs.py`, `tests/integration/test_retrain.py`

- [ ] Write tests for MP3-only scanning, labels, dedup, deterministic split, threshold calibration, versioned artifact.
- [ ] Implement; run tests.
- [ ] Commit.

### Task 10: Final verification

- [ ] `ruff check .`, `pytest -q`, Docker build smoke test.
- [ ] Verify latency target and update README.

