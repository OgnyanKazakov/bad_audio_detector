"""Codec-agnostic call-audio corruption detector."""

__version__ = "0.1.0"
