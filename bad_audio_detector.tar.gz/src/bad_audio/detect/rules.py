from __future__ import annotations

import numpy as np


def _clip01(value: float) -> float:
    return float(np.clip(value, 0.0, 1.0))


def rules_score(features: dict[str, float]) -> float:
    """Interpretable fallback score for p(incorrect_decoder)."""
    if features.get("insufficient_signal", 0.0) > 0.5:
        return 0.0
    flatness = _clip01((features.get("flatness_mean", 0.0) - 0.25) / 0.35)
    noisy = _clip01((8.0 - features.get("hnr_mean", 0.0)) / 12.0)
    unvoiced = _clip01((0.25 - features.get("voiced_fraction", 0.0)) / 0.25)
    low_modulation = _clip01((0.02 - features.get("modulation_2_8", 0.0)) / 0.02)
    high_flux = _clip01((features.get("flux_mean", 0.0) - 0.4) / 0.6)
    return _clip01(
        0.25 * flatness
        + 0.35 * noisy
        + 0.25 * unvoiced
        + 0.10 * low_modulation
        + 0.05 * high_flux
    )
