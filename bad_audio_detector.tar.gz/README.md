# Bad Audio Detector

A codec-agnostic call-audio integrity service. It answers one question:

```json
{"verdict": "correct_decoder"}
```

or

```json
{"verdict": "incorrect_decoder"}
```

`correct_decoder` means the audio still contains intact speech / call signals.
`incorrect_decoder` means the audio was destroyed by a wrong codec or wrong
decoder (noise-like, metallic, broken pitch/formant structure, or scrambled
waveform).

- **Development input:** MP3 files. WAV and raw PCM are also accepted for testing.
- **Production input:** PCM or RTP over WebSocket.
- **Detection:** codec-robust spectral/speech features plus a small
  HistGradientBoosting classifier, with a rule-based fallback.
- **Scope:** catastrophic corruption only. Packet loss, reordering, DTX, DTMF,
  ringback, and tones are valid call audio and must not be flagged.
- **Not in scope:** identifying *which* codec was wrong, and subtle mismatches
  such as A-law vs µ-law or bandwidth-only mismatches.

---

## 1. Implementation decisions

### 1.1 Binary integrity, not codec identification

The service deliberately does **not** identify the codec. It measures whether
the speech signal is still coherent. This keeps the detector independent of the
call platform and avoids maintaining a codec fingerprint database. The cost is
that it cannot report the actual codec or distinguish catastrophic mismatches
from other severe corruption. That matches the requested contract.

### 1.2 Canonical audio format

All inputs are converted to **mono float32 at 16 kHz** before analysis. This
covers narrowband (8 kHz) and wideband (16 kHz) calls, and makes the feature
extractor and model independent of the RTP codec. Decoding/resampling happens in
the ingestion adapters.

### 1.3 Feature-based supervised detection (chosen over rule-only or CNN)

Three approaches were considered:

1. **Rule-only DSP:** simple and interpretable, but brittle across codecs,
   noise, and tones, and hard to tune for high recall without false alarms.
2. **Handcrafted features + small classifier (selected):** high accuracy with
   modest data, CPU-fast, explainable evidence, and easy threshold control.
3. **Spectrogram CNN/CRNN:** higher ceiling with large real datasets, but more
   CPU, less interpretable, and prone to shortcut learning.

The selected model is a **HistGradientBoostingClassifier** over ~101
codec-robust features, with the rule-based scorer as a fallback when no model
artifact is present.

### 1.4 Multi-cue spectral features, not just cutoff frequency

Research on lossy-codec identification shows that a model trained only on
bandwidth/cutoff learns a confound and collapses when codec parameters change
(see the 2024 arXiv study in §15). The detector therefore combines:

- spectral shape: flatness, centroid, spread, rolloff, entropy, crest, flux;
- band-energy ratios from 300 Hz to 8 kHz;
- speech structure: autocorrelation pitch, HNR, voicing, pitch jitter, LPC
  prediction error;
- temporal structure: 2–8 Hz syllable modulation and activity fraction;
- codec artifacts: spectral holes and normalized bandwidth edge.

Statistics (`mean`, `std`, `p10`, `p50`, `p90`) are aggregated over
speech/active frames in each 1 s window. Silence and invalid/gap frames are
excluded through a VAD mask and RTP gap mask.

### 1.5 Decision policy favors recall

The default operating point targets **recall ≥ 0.98 at precision ≥ 0.85**. The
threshold is selected from the validation PR curve with a lower bound of `0.1`
to avoid pathological "flag everything" thresholds. The verdict uses a
consecutive-window rule (`CONSECUTIVE_WINDOWS`) so a single noisy window does
not flip the call. `THRESHOLD_OVERRIDE` can force an explicit threshold.

### 1.6 Insufficient signal is not corruption

If a window contains less than ~0.3 s of speech/tones, the window is marked
`insufficient`, and a call with no usable signal returns
`correct_decoder` with `insufficient_signal: true` and `confidence: null`.
This preserves the binary response contract without turning silence into a
false alarm.

### 1.7 Dev = MP3, prod = RTP, but the same detector

- The file API decodes MP3/WAV/PCM with PyAV and feeds the common pipeline.
- The WebSocket API accepts raw PCM or RTP.
- Synthetic training generates **MP3 (and some WAV) variants for both
  classes**, so the model cannot learn "MP3 vs non-MP3" as a shortcut.
- RTP decoding feeds the same 16 kHz detector after depacketization and codec
  decode.

### 1.8 RTP is decoded with pluggable depacketizers

The RTP stack is split into independent units:

1. RFC 3550 header parser (padding, CSRCs, extensions).
2. Jitter/reorder buffer with duplicate and loss accounting.
3. Codec registry (`CodecSpec`: RTP clock, sample rate, channels, options).
4. Per-codec depacketizer producing `EncodedFrame`s with per-frame timestamps.
5. Decoder backend (PyAV/native G.711) producing PCM plus a validity mask.

Adding a codec means adding a `CodecSpec` and a depacketizer; the detector does
not change.

### 1.9 AMR multiframe and BE/OA support

RFC 4867 AMR-NB/AMR-WB are handled in both modes:

- **Bandwidth-efficient:** 4-bit CMR, 6-bit TOC entries (`F|FT|Q`), bit-packed
  speech frames, whole-payload octet alignment.
- **Octet-aligned:** CMR byte, one-byte TOC per frame (`F|FT|Q|P`), optional
  per-frame CRC list, octet-aligned frames.
- **Multiframe:** any number of frames per packet (bounded by config), with
  `timestamp + i × frame_samples`.
- **SID / NO_DATA / SPEECH_LOST:** timeline advances; no-data frames are marked
  invalid and excluded from detection.
- **Interleaving / robust sorting:** detected and rejected explicitly rather
  than silently mis-decoded.

### 1.10 Packet loss and jitter are valid

The jitter buffer reorders packets and tracks loss/duplicates. Lost frames
become a **gap mask** rather than concealment noise. Features skip gaps and
report `gap_fraction`, so packet loss is not mistaken for codec corruption.

### 1.11 Synthetic data includes realistic "good" variation

The generator creates good-class audio with:

- multiple codecs (PCMU, PCMA, G.722, AMR-NB, Opus, MP3);
- noise at 10/20/30/60 dB SNR;
- 0/1/3% packet loss;
- DTMF, ringback, continuous tones, 1 kHz tones;
- leading/trailing silence and hold-like segments.

Bad-class audio is produced by encoding with one codec and interpreting the
compressed bytes with a mismatched waveform decoder, then applying a call-like
energy envelope. This gives a realistic catastrophic mismatch without needing a
G.729 encoder.

### 1.12 MP3 good/bad folders for future adjustment

Two directories are configurable through `.env`:

```env
GOOD_RECORDS_DIR=data/records/good
BAD_RECORDS_DIR=data/records/bad
```

- Every `.mp3` under `GOOD_RECORDS_DIR` is labeled `correct_decoder`.
- Every `.mp3` under `BAD_RECORDS_DIR` is labeled `incorrect_decoder`.
- Files are deduplicated by SHA-256.
- The train/eval split is deterministic by file hash (`REAL_EVAL_FRACTION`).
- The running service never scans these folders; only offline tooling does.
- `calibrate_threshold.py` adjusts the operating point without retraining.
- `retrain_from_dirs.py` retrains with synthetic + real data and refuses to
  publish a model that falls below `MIN_RECALL` / `MIN_PRECISION`.

### 1.13 Model versioning and safe reload

Retraining writes a versioned artifact under `models/detector-<timestamp>/`
and publishes `models/current/`. `train.py` writes directly to the configured
output path. Retraining is offline only. The service reloads on restart or
through a token-protected `POST /v1/admin/reload`.

### 1.14 Privacy and operational safety

- Raw audio is not logged or persisted by the service.
- Uploads are capped by `MAX_UPLOAD_MB`.
- Folder tooling uses hashes for deduplication and does not copy raw audio.
- Admin reload requires `X-Admin-Token` when `ADMIN_TOKEN` is set.
- RTP unknown payload types fail with an explicit error rather than guessing.

### 1.15 Packaging

Python 3.10, FastAPI, PyAV, numpy/scipy/scikit-learn. Docker includes FFmpeg and
AMR libraries. `soundfile` is a dev/test dependency only.

---

## 2. Architecture

```text
HTTP POST /v1/analyze
  MP3/WAV/PCM -> PyAV decode -> 16 kHz mono float32
                                |
WebSocket /v1/stream             v
  PCM frames -------------> resample 16 kHz
  RTP packets -> header -> jitter/reorder/dedup
              -> codec registry -> depacketizer
              -> decoder -> PCM + valid/gap mask
                                |
                                v
                   32 ms frames / 10 ms hop
                                |
                   VAD + tone detection + features
                                |
                  1 s windows / 0.5 s hop
                                |
              HistGradientBoosting or rules fallback
                                |
             smoothing + consecutive-window decision
                                |
                   correct_decoder / incorrect_decoder
```

### 2.1 Module map

```text
src/bad_audio/
  config.py                      .env / environment settings
  pipeline.py                    Detector, windowing, evidence, API result
  api/
    app.py                       FastAPI HTTP + WebSocket + admin reload
    schemas.py                   response models
  io/
    audio.py                     PyAV decode, PCM, resampling
    rtp/
      header.py                  RFC 3550 parser
      jitter.py                  reorder/dedupe/loss
      specs.py                   CodecSpec registry / PT defaults
      sdp.py                     SDP + fmtp parser
      decoder.py                 codec decode + gap mask
      depacketizer/
        base.py                  EncodedFrame
        g711.py g722.py g729.py amr.py opus.py ilbc.py l16.py cn.py
        __init__.py              registry + dispatch
  dsp/
    framing.py                   frame extraction
    vad.py                       energy VAD
    tones.py                     DTMF/ringback tone detection
    features.py                  101 features + aggregation
    aggregate.py                 window bounds
  detect/
    rules.py                     interpretable fallback score
    model.py                     model artifact load/save/score
    decision.py                  consecutive-window verdict
    metrics.py                   PR threshold selection, metrics
  streaming/
    session.py                   PCM/RTP session state
  data/
    synthetic.py                 speech/tone synthesis + codec simulation
    dataset.py                   manifests + feature matrices
    labeled_dirs.py              MP3 folder scan/dedup/split
scripts/
  generate_dataset.py            synthetic MP3/WAV dataset
  train.py                       train + calibrate + evaluate
  evaluate.py                    evaluate a manifest
  calibrate_threshold.py         threshold-only adjustment
  retrain_from_dirs.py           real MP3 retraining + guarded publish
models/current/                  shipped baseline model + metrics + threshold
```

---

## 3. Configuration

Copy `.env.example` to `.env`. Settings are read with
`pydantic-settings`; environment variables override `.env`.

| Variable | Default | Meaning |
|---|---|---|
| `APP_MODE` | `dev` | Informational mode (`dev` / `prod`). |
| `INGEST_MODE` | `file` | Informational ingress mode. |
| `RTP_DECODE` | `on` | Allow RTP sessions when true. |
| `TARGET_SAMPLE_RATE` | `16000` | Internal sample rate. |
| `WINDOW_SECONDS` | `1.0` | Detection window. |
| `HOP_SECONDS` | `0.5` | Window hop. |
| `DECISION_THRESHOLD` | `0.5` | Threshold for rules fallback. |
| `THRESHOLD_OVERRIDE` | unset | Forces a threshold even with a model. |
| `CONSECUTIVE_WINDOWS` | `2` | Consecutive windows needed to flag. |
| `MIN_ACTIVITY_SECONDS` | `0.5` | Minimum speech/tone activity. |
| `VAD_THRESHOLD` | `0.02` | Energy VAD gate. |
| `MODEL_PATH` | `models/current/detector.joblib` | Model artifact. |
| `MODELS_DIR` | `models` | Versioned model root. |
| `THRESHOLD_PATH` | `models/current/threshold.json` | Threshold file. |
| `GOOD_RECORDS_DIR` | `data/records/good` | Correct MP3 folder. |
| `BAD_RECORDS_DIR` | `data/records/bad` | Incorrect MP3 folder. |
| `RECORDS_RECURSIVE` | `true` | Scan subdirectories. |
| `REAL_EVAL_FRACTION` | `0.2` | Deterministic real eval split. |
| `REAL_DATA_WEIGHT` | `1.0` | Real-data sample weight. |
| `MIN_RECALL` | `0.98` | Publish gate. |
| `MIN_PRECISION` | `0.85` | Publish gate. |
| `ADMIN_TOKEN` | empty | Required for admin reload if set. |
| `JITTER_BUFFER_MS` | `200` | RTP reorder depth. |
| `MAX_FRAMES_PER_PACKET` | `10` | AMR multiframe bound. |
| `PAYLOAD_TYPE_MAP` | empty | JSON map, e.g. `{"96":"AMR-WB"}`. |
| `MAX_UPLOAD_MB` | `50` | HTTP upload cap. |

---

## 4. How to use

### 4.1 Install and run

```bash
python3 -m pip install -e ".[dev]"
cp .env.example .env
uvicorn bad_audio.api.app:app --host 0.0.0.0 --port 8000
```

If the package is not installed, run with `PYTHONPATH=src`:

```bash
PYTHONPATH=src uvicorn bad_audio.api.app:app --reload
```

The service loads `MODEL_PATH` if it exists. A baseline synthetic model is
shipped in `models/current/`; otherwise the rule fallback is used.

### 4.2 Analyze a file

```bash
curl -s -X POST http://localhost:8000/v1/analyze \
  -F "file=@call.mp3"
```

Example response:

```json
{
  "verdict": "correct_decoder",
  "confidence": 0.99,
  "insufficient_signal": false,
  "windows": [
    {"start_s": 0.0, "end_s": 1.0, "p_incorrect": 0.01, "insufficient": false}
  ],
  "evidence": {
    "flatness_mean": 0.12,
    "hnr_mean": 10.4,
    "voiced_fraction": 0.71,
    "modulation_2_8": 0.08,
    "flux_mean": 0.04,
    "rolloff_norm_mean": 0.22,
    "gap_fraction": 0.0
  },
  "model_version": "20261021-124345",
  "latency_ms": 24.1
}
```

Raw PCM is accepted with a declared sample rate and format:

```bash
curl -s -X POST http://localhost:8000/v1/analyze \
  -F "file=@call.pcm" \
  -F "sample_rate=8000" \
  -F "pcm_format=s16le"
```

Supported formats: `s16le`, `s16be`, `f32le`, `f32be`. PCM is assumed mono.

### 4.3 WebSocket PCM stream

Connect to `ws://localhost:8000/v1/stream`. The server sends:

```json
{"type":"ready"}
```

Send a config message:

```json
{"type":"config","format":"pcm","sample_rate":16000,"pcm_format":"s16le"}
```

Then send binary PCM chunks. The server emits `window` messages and, at end of
stream, a `verdict`:

```json
{"type":"window","start_s":0.0,"end_s":1.0,"p_incorrect":0.02,"insufficient":false}
```

```json
{"type":"eos"}
```

```json
{
  "type": "verdict",
  "verdict": "correct_decoder",
  "confidence": 0.98,
  "insufficient_signal": false,
  "windows": [],
  "evidence": {},
  "model_version": "20261021-124345",
  "latency_ms": 0.0
}
```

### 4.4 WebSocket RTP stream

Config with explicit codec metadata:

```json
{
  "type": "config",
  "format": "rtp",
  "payload_type": 96,
  "codec": "AMR-WB",
  "clock_rate": 16000,
  "channels": 1,
  "octet_align": 0,
  "amr_crc": 0
}
```

Or with SDP:

```json
{"type":"config","format":"rtp","sdp":"v=0\r\nm=audio 49170 RTP/AVP 96\r\na=rtpmap:96 AMR-WB/16000/1\r\na=fmtp:96 octet-align=1\r\n"}
```

Then send each RTP packet as one binary WebSocket message, followed by
`{"type":"eos"}`. Dynamic payload types not present in SDP can be mapped with
`PAYLOAD_TYPE_MAP`:

```env
PAYLOAD_TYPE_MAP={"96":"AMR-WB","97":"AMR-NB","111":"OPUS"}
```

### 4.5 Minimal Python WebSocket client

```python
import asyncio
import json

import websockets


async def main() -> None:
    async with websockets.connect("ws://localhost:8000/v1/stream") as ws:
        print(await ws.recv())  # ready
        await ws.send(json.dumps({
            "type": "config",
            "format": "pcm",
            "sample_rate": 16000,
            "pcm_format": "s16le",
        }))
        with open("call.pcm", "rb") as handle:
            while chunk := handle.read(3200):
                await ws.send(chunk)
        await ws.send(json.dumps({"type": "eos"}))
        while True:
            message = json.loads(await ws.recv())
            print(message)
            if message["type"] in ("verdict", "error"):
                break


asyncio.run(main())
```

### 4.6 Admin reload

After retraining:

```bash
curl -s -X POST http://localhost:8000/v1/admin/reload \
  -H "X-Admin-Token: $ADMIN_TOKEN"
```

If `ADMIN_TOKEN` is empty, the endpoint is open; set a token in production.

---

## 5. Training and data workflows

### 5.1 Generate synthetic MP3/WAV data

```bash
PYTHONPATH=src python scripts/generate_dataset.py \
  --out data/synthetic \
  --samples 120 \
  --seconds 3
```

Options:

- `--source-dir /path/to/clean/audio` uses real clean speech instead of the
  built-in formant synthesis source.
- `--codecs PCMU,PCMA,G722,AMR-NB,OPUS,MP3`.
- `--seed` controls deterministic generation.

The generator creates paired good/bad clips from the same source. Good clips
include codec round-trips, noise, packet loss, tones, and silence. Bad clips
misinterpret encoded bytes with a mismatched decoder. A mix of MP3 and WAV is
saved so both dev and PCM/RTP-like conditions are represented.

The manifest is CSV:

```text
path,label,codec,source_id,mode,snr,loss,weight
```

### 5.2 Train and evaluate

```bash
PYTHONPATH=src python scripts/train.py \
  --manifest data/synthetic/manifest.csv
```

This writes:

- `models/current/detector.joblib`
- `models/current/metrics.json`
- `models/current/threshold.json`

`--out`, `--metrics-out`, `--min-precision`, and `--min-recall` override the
defaults. The training script splits by `source_id` where possible, selects a
threshold from the validation PR curve, reports overall and per-codec metrics,
and refuses to save below the target unless `--allow-below-target` is passed.

Evaluate any manifest separately:

```bash
PYTHONPATH=src python scripts/evaluate.py \
  --manifest data/manifest.csv \
  --model models/current/detector.joblib
```

### 5.3 Add real good/bad MP3 folders

```text
data/records/good/*.mp3   -> correct_decoder
data/records/bad/*.mp3    -> incorrect_decoder
```

Set `GOOD_RECORDS_DIR` and `BAD_RECORDS_DIR` in `.env`. Non-MP3 files are
ignored; duplicates are removed by SHA-256; the eval split is deterministic by
file hash.

### 5.4 Calibrate the threshold only

```bash
PYTHONPATH=src python scripts/calibrate_threshold.py
```

Uses the folders, model, thresholds, and precision/recall targets from `.env`.
This is the fastest adjustment when the model already separates the classes but
the operating point needs to favor recall or precision.

### 5.5 Retrain with real data

```bash
PYTHONPATH=src python scripts/retrain_from_dirs.py
```

- Combines real training MP3s with synthetic data (if
  `data/synthetic/manifest.csv` exists).
- Uses `REAL_DATA_WEIGHT`, `REAL_EVAL_FRACTION`, `MIN_RECALL`, and
  `MIN_PRECISION` from `.env`.
- Evaluates on the held-out real split.
- Writes `models/detector-<timestamp>/` and publishes to `models/current/`.
- Exits non-zero if the recall/precision floors are not met.
- Reload the service afterward.

---

## 6. RTP codec support

| Codec | RTP clock | Decoded rate | Framing | Multiframe | Notes |
|---|---:|---:|---|---|---|
| PCMU / PCMA | 8000 | 8000 | sample | n/a | Native G.711 decode |
| G.722 | 8000 | 16000 | sample | n/a | Clock intentionally 8 kHz |
| G.729 | 8000 | 8000 | 10 ms | yes | N × 10-byte frames + optional CN |
| AMR-NB | 8000 | 8000 | 20 ms | yes | BE/OA, CMR/TOC, SID/NO_DATA |
| AMR-WB | 16000 | 16000 | 20 ms | yes | BE/OA, CMR/TOC, SID/NO_DATA |
| Opus | 48000 | 48000→16k | packet | internal | Decoder handles packet frames |
| iLBC | 8000 | 8000 | 20/30 ms | no | 38/50-byte frames, one per packet |
| L16 | configurable | match | sample | n/a | 16-bit big-endian PCM |
| CN | 8000 | 8000 | 20 ms | n/a | Comfort noise, non-speech |

Payload-type defaults: `0=PCMU`, `8=PCMA`, `9=G722`, `13=CN`, `18=G729`.
Dynamic types come from SDP, per-stream config, or `PAYLOAD_TYPE_MAP`.

AMR and G.729 encoders are not required at runtime; only decoders. The
synthetic generator uses codecs that PyAV can encode in this environment
(PCMU/PCMA/G.722/AMR-NB/Opus/MP3); AMR-WB and G.729 decoding are still
supported by the service.

---

## 7. Feature reference

Per 32 ms frame:

- `flatness`, `centroid`, `spread`, `rolloff`, `entropy`, `crest`, `flux`,
  `zcr`;
- `hnr`, `voicing`, `f0`, `lpc_error`;
- `band1`–`band5` (300–1k, 1–2k, 2–4k, 4–6k, 6–8k Hz);
- `holes` (fraction of near-empty spectral bins) and `rolloff_norm`.

Per window, each base feature gets `mean`, `std`, `p10`, `p50`, `p90`. Extras:

- `active_fraction`, `voiced_fraction`, `pitch_jitter`;
- `modulation_2_8` (syllabic envelope modulation);
- `gap_fraction` (RTP loss/DTX);
- `insufficient_signal`.

Total: **101 features**.

---

## 8. Implementation steps (what was built)

1. **Scaffold** — `pyproject.toml`, package layout, `.env.example`,
   `Settings`, FastAPI health/readiness, Dockerfile, compose file.
2. **RTP foundation** — RFC 3550 parser, CSRC/extension/padding handling,
   jitter buffer with wrap-around, duplicates, loss accounting.
3. **Codec layer** — `CodecSpec` registry, SDP/fmtp parser, depacketizers for
   G.711, G.722, G.729, AMR-NB/WB (BE/OA + multiframe), Opus, iLBC, L16, CN.
4. **Audio I/O** — PyAV decode to 16 kHz mono, PCM readers, polyphase
   resampling, codec decode with gap masks.
5. **DSP** — framing, energy VAD, DTMF/tone detection, spectral/speech
   features, window aggregation.
6. **Detection** — rules fallback, model artifact load/save, consecutive-window
   decision, `Detector` pipeline with evidence and latency.
7. **Data** — synthetic speech/tone generation, codec round-trips, wrong-decoder
   simulation, MP3/WAV dataset generation, manifests, feature matrices.
8. **Training** — grouped splits, class weighting, HGB training, PR-based
   threshold calibration, per-codec metrics, model versioning.
9. **API** — `POST /v1/analyze`, WebSocket PCM/RTP streaming, EOS verdict,
   admin reload, upload limits.
10. **Real-data tooling** — MP3 folder scan/dedup/split, threshold
    recalibration, guarded retraining, publish to `models/current`.
11. **Verification** — unit/integration tests, live HTTP smoke test, latency
    measurement, Dockerfile prepared.

---

## 9. Testing and measured results

```bash
python -m pytest -q
python -m ruff check .
```

Current status in this repository:

- **53 tests passed** (unit + integration).
- `ruff` clean.
- Held-out synthetic validation: **100% accuracy / precision / recall**
  (40 clips) with the shipped model.
- Live service smoke test: good MP3 → `correct_decoder`, bad MP3 →
  `incorrect_decoder`.
- Measured latency on the development machine: ~85 ms for a 3 s MP3,
  ~28 ms per 1 s analysis window.
- Docker image build was not executed because the Docker daemon was not
  running in the development environment; the Dockerfile and compose file are
  included.

The synthetic validation number is not a production accuracy claim. Real call
data should be added through the two MP3 folders and used for threshold
calibration/retraining.

---

## 10. Docker

```bash
docker compose up --build
```

The image installs Python dependencies plus FFmpeg/AMR libraries, creates
`/data/records/good` and `/data/records/bad`, and runs Uvicorn on port 8000.
The compose file mounts `./models` and `./data/records`, and overrides the
container paths for the model and labeled folders.

---

## 11. Troubleshooting

- **Service uses rules, not the model:** check `MODEL_PATH` exists and is
  readable. `GET /readyz` reports the loaded model version.
- **`unknown RTP payload type`:** provide `codec`/`clock_rate` in the stream
  config, send SDP, or set `PAYLOAD_TYPE_MAP`.
- **`insufficient_signal: true`:** the window had less than the minimum
  speech/tones. This is neutral, not corruption.
- **Retraining exits non-zero:** the held-out real split did not meet
  `MIN_RECALL`/`MIN_PRECISION`. Add more labeled MP3s or review the folders.
- **Folder scanner ignores a file:** only `.mp3` is accepted in
  `GOOD_RECORDS_DIR` and `BAD_RECORDS_DIR`.
- **AMR/G.729 decode fails:** ensure PyAV is installed with the relevant
  decoder; the Docker image includes the libraries.
- **Docker build fails:** confirm the Docker daemon is running and that
  `models/` exists (the image copies the shipped artifact).

---

## 12. Limitations and future work

- Catastrophic corruption only. Subtle A-law/µ-law or bandwidth-only mismatches
  are not detected.
- The shipped model is trained on synthetic speech; real-call calibration is
  required before production accuracy claims.
- Interleaved/robust-sorted AMR is rejected, not reconstructed.
- The service does not identify the wrong codec, only whether the audio is
  corrupted.
- Possible future work: real-call feature collection, per-codec calibration,
  a CNN/CRNN model, and AMR interleaving support.

---

## 13. Research references

- *Robust lossy audio compression identification*, arXiv:2407.21545 (2024):
  cutoff-frequency shortcut, spectral holes, random masking.
- *Audio codec identification from coded and transcoded audios*, Digital Signal
  Processing (2013): codec design choices leave measurable signatures.
- B. Kim and Z. Rafii, *Lossy audio compression identification*, EUSIPCO 2018.
- Telephony channel validation guidance on codec-robust spectral-envelope and
  source-excitation features for G.711/AMR-NB/wideband channels.
- RFC 3550 (RTP), RFC 3551 (RTP audio profile), RFC 4867 (AMR/AMR-WB RTP
  payload formats and BE/OA multiframe), RFC 3389 (comfort noise).
