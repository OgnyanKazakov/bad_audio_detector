from __future__ import annotations

import os
from dataclasses import dataclass

import joblib
import numpy as np

from ..dsp.features import FEATURE_NAMES


@dataclass
class ModelArtifact:
    model: object
    feature_names: list[str]
    threshold: float
    version: str


class DetectorModel:
    def __init__(self, artifact: ModelArtifact) -> None:
        self.artifact = artifact

    @property
    def version(self) -> str:
        return self.artifact.version

    @property
    def threshold(self) -> float:
        return self.artifact.threshold

    def score(self, features: dict[str, float]) -> float:
        names = self.artifact.feature_names
        vector = np.asarray([[float(features.get(name, 0.0)) for name in names]], dtype=np.float32)
        model = self.artifact.model
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(vector)[0]
            classes = list(getattr(model, "classes_", [0, 1]))
            if 1 in classes:
                return float(proba[classes.index(1)])
            return float(proba[-1])
        return float(model.predict(vector)[0])


def save_model(
    path: str,
    model: object,
    feature_names: list[str] | None = None,
    threshold: float = 0.5,
    version: str = "unknown",
) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    artifact = ModelArtifact(
        model=model,
        feature_names=list(feature_names or FEATURE_NAMES),
        threshold=float(threshold),
        version=version,
    )
    tmp = f"{path}.tmp"
    joblib.dump(artifact, tmp)
    os.replace(tmp, path)


def load_model(path: str) -> DetectorModel | None:
    if not path or not os.path.exists(path):
        return None
    try:
        artifact = joblib.load(path)
    except Exception:
        return None
    if isinstance(artifact, dict):
        artifact = ModelArtifact(
            model=artifact["model"],
            feature_names=list(artifact.get("feature_names", FEATURE_NAMES)),
            threshold=float(artifact.get("threshold", 0.5)),
            version=str(artifact.get("version", "unknown")),
        )
    if not isinstance(artifact, ModelArtifact):
        return None
    return DetectorModel(artifact)


def build_default_model() -> object:
    from sklearn.ensemble import HistGradientBoostingClassifier

    return HistGradientBoostingClassifier(
        max_iter=200,
        learning_rate=0.08,
        max_depth=4,
        l2_regularization=1.0,
        random_state=0,
    )
