from __future__ import annotations

from .base import Depacketizer, EncodedFrame

_OPUS_FRAME_MS = {
    0: 10.0, 1: 20.0, 2: 40.0, 3: 60.0,
    4: 10.0, 5: 20.0, 6: 40.0, 7: 60.0,
    8: 10.0, 9: 20.0, 10: 40.0, 11: 60.0,
    12: 10.0, 13: 20.0,
    14: 10.0, 15: 20.0,
    16: 2.5, 17: 5.0, 18: 10.0, 19: 20.0,
    20: 2.5, 21: 5.0, 22: 10.0, 23: 20.0,
    24: 2.5, 25: 5.0, 26: 10.0, 27: 20.0,
    28: 2.5, 29: 5.0, 30: 10.0, 31: 20.0,
}


class OpusDepacketizer(Depacketizer):
    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        payload = packet.payload
        if not payload:
            return []
        toc = payload[0]
        config = toc >> 3
        code = toc & 0x03
        if config not in _OPUS_FRAME_MS:
            raise ValueError("invalid Opus TOC config")
        if code == 0:
            count = 1
        elif code in (1, 2):
            count = 2
        else:
            if len(payload) < 2:
                raise ValueError("truncated Opus packet")
            count = payload[1] & 0x3F
        if count < 1:
            raise ValueError("invalid Opus frame count")
        duration = int(round(_OPUS_FRAME_MS[config] * count * 48))
        return [
            EncodedFrame(
                codec=spec.encoding,
                data=payload,
                rtp_timestamp=packet.timestamp,
                duration=duration,
                sample_rate=spec.sample_rate,
                channels=spec.channels,
                sequence=packet.sequence,
            )
        ]
