"""Streaming session handling."""
