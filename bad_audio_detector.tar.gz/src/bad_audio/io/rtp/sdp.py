from __future__ import annotations

from .specs import CodecSpec, make_spec, normalize_encoding, spec_from_pt


def parse_sdp(text: str) -> dict[int, CodecSpec]:
    payload_types: list[int] = []
    rtpmap: dict[int, tuple[str, int, int]] = {}
    fmtp: dict[int, dict[str, str]] = {}

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("m=audio"):
            parts = line.split()
            payload_types = [int(p) for p in parts[3:]]
        elif line.startswith("a=rtpmap:"):
            rest = line[len("a=rtpmap:") :]
            pt_str, encoding = rest.split(None, 1)
            fields = encoding.split("/")
            name = fields[0]
            clock = int(fields[1])
            channels = int(fields[2]) if len(fields) > 2 else 1
            rtpmap[int(pt_str)] = (name, clock, channels)
        elif line.startswith("a=fmtp:"):
            rest = line[len("a=fmtp:") :]
            pt_str, params = rest.split(None, 1)
            parsed: dict[str, str] = {}
            for item in params.split(";"):
                item = item.strip()
                if not item:
                    continue
                if "=" in item:
                    key, value = item.split("=", 1)
                    parsed[key.strip().lower()] = value.strip()
                else:
                    parsed[item.lower()] = ""
            fmtp[int(pt_str)] = parsed

    specs: dict[int, CodecSpec] = {}
    for pt in payload_types or sorted(set(rtpmap) | set(fmtp)):
        base = spec_from_pt(pt) if pt not in rtpmap else None
        if base is not None:
            specs[pt] = base
            continue
        name, clock, channels = rtpmap[pt]
        params = fmtp.get(pt, {})
        overrides = {
            "rtp_clock_rate": clock,
            "sample_rate": clock,
            "channels": channels,
        }
        canonical = normalize_encoding(name)
        if canonical in ("OPUS",):
            overrides["sample_rate"] = 48000
        if canonical in ("AMR-NB", "AMR-WB"):
            overrides["octet_align"] = params.get("octet-align", "0") == "1"
            overrides["amr_crc"] = params.get("crc", "0") == "1"
            overrides["robust_sorting"] = params.get("robust-sorting", "0") == "1"
            interleaving = int(params.get("interleaving", "0") or "0")
            overrides["interleaving"] = interleaving > 0
            mode_set = params.get("mode-set")
            if mode_set:
                overrides["mode_set"] = tuple(int(v) for v in mode_set.split(",") if v)
        specs[pt] = make_spec(canonical, **overrides)
    return specs
