from __future__ import annotations

from dataclasses import dataclass

from .header import RtpPacket

_SEQ_MOD = 1 << 16


def _seq_diff(a: int, b: int) -> int:
    """Signed distance from b to a in 16-bit RTP sequence space."""
    return ((a - b + (_SEQ_MOD // 2)) % _SEQ_MOD) - (_SEQ_MOD // 2)


@dataclass
class JitterStats:
    duplicates: int = 0
    lost: int = 0
    late: int = 0
    received: int = 0


class JitterBuffer:
    """Reorder packets by RTP sequence number.

    The first packet seen establishes the starting sequence. Packets that arrive
    after their slot has been delivered are counted as late and dropped.
    Missing sequences are counted as lost when the buffer advances past them.
    """

    def __init__(self, depth: int = 2) -> None:
        self.depth = max(0, depth)
        self._buf: dict[int, RtpPacket] = {}
        self._next: int | None = None
        self._max_seq: int | None = None
        self.stats = JitterStats()

    def push(self, packet: RtpPacket) -> None:
        seq = packet.sequence
        if self._next is None:
            self._next = seq
            self._max_seq = seq
        if seq in self._buf:
            self.stats.duplicates += 1
            return
        if self._next is not None and _seq_diff(seq, self._next) < 0:
            self.stats.late += 1
            return
        self._buf[seq] = packet
        self.stats.received += 1
        if self._max_seq is None or _seq_diff(seq, self._max_seq) > 0:
            self._max_seq = seq

    def drain(self, force: bool = False) -> list[RtpPacket]:
        if self._next is None:
            return []
        if not force and self.depth > 0:
            buffered_ahead = sum(
                1 for seq in self._buf if _seq_diff(seq, self._next) > 0
            )
            if buffered_ahead < self.depth:
                return []
        out: list[RtpPacket] = []
        while self._next is not None:
            if self._next in self._buf:
                out.append(self._buf.pop(self._next))
                self._next = (self._next + 1) % _SEQ_MOD
                continue
            if self._max_seq is None:
                break
            ahead = _seq_diff(self._max_seq, self._next)
            if ahead <= 0:
                break
            if not force and ahead < self.depth:
                break
            self.stats.lost += 1
            self._next = (self._next + 1) % _SEQ_MOD
        return out

    def flush(self) -> list[RtpPacket]:
        return self.drain(force=True)

    def reset(self) -> None:
        self._buf.clear()
        self._next = None
        self._max_seq = None
        self.stats = JitterStats()
