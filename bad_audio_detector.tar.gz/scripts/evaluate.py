#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

import numpy as np

from bad_audio.data.dataset import build_matrix, read_manifest
from bad_audio.detect.metrics import binary_metrics
from bad_audio.detect.model import load_model


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a trained detector on a manifest")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--model", default="models/current/detector.joblib")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()

    loaded = load_model(args.model)
    if loaded is None:
        raise SystemExit(f"cannot load model {args.model}")
    rows = read_manifest(args.manifest)
    X, y, _, kept = build_matrix(rows, verbose=False)
    if len(X) == 0:
        raise SystemExit("no readable audio")
    scores = np.asarray(
        [loaded.score(dict(zip(loaded.artifact.feature_names, row))) for row in X],
        dtype=float,
    )
    threshold = args.threshold if args.threshold is not None else loaded.threshold
    metrics = binary_metrics(y, scores, threshold)
    per_codec = {}
    for codec in sorted({r.codec for r in kept}):
        mask = np.asarray([r.codec == codec for r in kept])
        if mask.sum() and len(np.unique(y[mask])) > 1:
            per_codec[codec] = binary_metrics(y[mask], scores[mask], threshold)
    metrics["per_codec"] = per_codec
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
