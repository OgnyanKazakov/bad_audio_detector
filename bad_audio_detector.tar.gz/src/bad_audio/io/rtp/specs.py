from __future__ import annotations

from dataclasses import dataclass, replace


@dataclass(frozen=True, slots=True)
class CodecSpec:
    encoding: str
    rtp_clock_rate: int
    sample_rate: int
    channels: int = 1
    octet_align: bool = False
    amr_crc: bool = False
    interleaving: bool = False
    robust_sorting: bool = False
    mode_set: tuple[int, ...] | None = None
    decoder: str | None = None
    max_frames_per_packet: int = 10


_ALIASES = {
    "PCMU": "PCMU",
    "PCMA": "PCMA",
    "G711U": "PCMU",
    "G711A": "PCMA",
    "G722": "G722",
    "G729": "G729",
    "G729D": "G729",
    "G729E": "G729",
    "AMR": "AMR-NB",
    "AMR-NB": "AMR-NB",
    "AMRNB": "AMR-NB",
    "AMR-WB": "AMR-WB",
    "AMRWB": "AMR-WB",
    "OPUS": "OPUS",
    "ILBC": "ILBC",
    "L16": "L16",
    "CN": "CN",
    "COMFORTNOISE": "CN",
}

_DEFAULTS: dict[str, CodecSpec] = {
    "PCMU": CodecSpec("PCMU", 8000, 8000, decoder="pcm_mulaw"),
    "PCMA": CodecSpec("PCMA", 8000, 8000, decoder="pcm_alaw"),
    "G722": CodecSpec("G722", 8000, 16000, decoder="g722"),
    "G729": CodecSpec("G729", 8000, 8000, decoder="g729"),
    "AMR-NB": CodecSpec("AMR-NB", 8000, 8000, octet_align=False, decoder="amrnb"),
    "AMR-WB": CodecSpec("AMR-WB", 16000, 16000, octet_align=False, decoder="amrwb"),
    "OPUS": CodecSpec("OPUS", 48000, 48000, decoder="opus"),
    "ILBC": CodecSpec("ILBC", 8000, 8000, decoder="ilbc"),
    "L16": CodecSpec("L16", 8000, 8000, decoder="pcm_s16be"),
    "CN": CodecSpec("CN", 8000, 8000, decoder=None),
}

PT_DEFAULTS: dict[int, str] = {
    0: "PCMU",
    8: "PCMA",
    9: "G722",
    13: "CN",
    18: "G729",
}


def normalize_encoding(encoding: str) -> str:
    key = encoding.strip().upper()
    try:
        return _ALIASES[key]
    except KeyError as exc:
        raise ValueError(f"unsupported codec {encoding!r}") from exc


def make_spec(encoding: str, **overrides) -> CodecSpec:
    name = normalize_encoding(encoding)
    spec = _DEFAULTS[name]
    return replace(spec, **overrides)


def spec_from_pt(payload_type: int, overrides: dict[int, CodecSpec] | None = None) -> CodecSpec:
    if overrides and payload_type in overrides:
        return overrides[payload_type]
    try:
        name = PT_DEFAULTS[payload_type]
    except KeyError as exc:
        raise ValueError(f"unknown RTP payload type {payload_type}") from exc
    return make_spec(name)
