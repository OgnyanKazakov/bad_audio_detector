#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from bad_audio.config import get_settings
from bad_audio.data.dataset import ManifestRow, build_matrix
from bad_audio.data.labeled_dirs import scan_labeled_dirs
from bad_audio.detect.metrics import binary_metrics, choose_threshold
from bad_audio.detect.model import load_model, save_model


def main() -> None:
    parser = argparse.ArgumentParser(description="Recalibrate detector threshold from MP3 folders")
    parser.add_argument("--good-dir", default=None)
    parser.add_argument("--bad-dir", default=None)
    parser.add_argument("--model", default=None)
    parser.add_argument("--threshold-out", default=None)
    parser.add_argument("--no-recursive", action="store_true")
    parser.add_argument("--min-precision", type=float, default=None)
    parser.add_argument("--min-recall", type=float, default=None)
    args = parser.parse_args()

    settings = get_settings()
    good_dir = args.good_dir or settings.good_records_dir
    bad_dir = args.bad_dir or settings.bad_records_dir
    model_path = args.model or settings.model_path
    threshold_out = args.threshold_out or settings.threshold_path
    min_precision = args.min_precision if args.min_precision is not None else settings.min_precision
    min_recall = args.min_recall if args.min_recall is not None else settings.min_recall

    loaded = load_model(model_path)
    if loaded is None:
        raise SystemExit(f"cannot load model {model_path}")
    records = scan_labeled_dirs(good_dir, bad_dir, recursive=not args.no_recursive)
    if not records:
        raise SystemExit("no MP3 files found")
    rows = [
        ManifestRow(path=str(r.path), label=r.label, codec="real", source_id=r.sha256)
        for r in records
    ]
    X, y, _, kept = build_matrix(rows, verbose=True)
    if len(X) == 0:
        raise SystemExit("no readable audio")
    scores = np.asarray(
        [loaded.score(dict(zip(loaded.artifact.feature_names, row))) for row in X],
        dtype=float,
    )
    threshold = choose_threshold(y, scores, min_precision, min_recall)
    metrics = binary_metrics(y, scores, threshold)
    print(json.dumps(metrics, indent=2))
    save_model(
        model_path,
        loaded.artifact.model,
        loaded.artifact.feature_names,
        threshold=threshold,
        version=loaded.version,
    )
    Path(threshold_out).parent.mkdir(parents=True, exist_ok=True)
    Path(threshold_out).write_text(
        json.dumps({"threshold": threshold, "metrics": metrics}, indent=2),
        encoding="utf-8",
    )
    print(f"threshold={threshold:.4f}")


if __name__ == "__main__":
    main()
