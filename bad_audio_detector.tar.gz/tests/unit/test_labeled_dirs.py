from __future__ import annotations

from bad_audio.data.labeled_dirs import scan_labeled_dirs, split_records


def test_scan_mp3_only_and_labels(tmp_path):
    good = tmp_path / "good"
    bad = tmp_path / "bad"
    good.mkdir()
    bad.mkdir()
    (good / "a.mp3").write_bytes(b"good-a")
    (good / "b.MP3").write_bytes(b"good-b")
    (good / "notes.txt").write_text("skip me")
    (bad / "c.mp3").write_bytes(b"bad-c")
    (bad / "sub").mkdir()
    (bad / "sub" / "d.mp3").write_bytes(b"bad-d")

    records = scan_labeled_dirs(str(good), str(bad), recursive=True)
    assert len(records) == 4
    assert {r.label for r in records if r.path.suffix.lower() == ".mp3"} == {0, 1}
    by_name = {r.path.name: r for r in records}
    assert by_name["a.mp3"].label == 0
    assert by_name["c.mp3"].label == 1
    assert by_name["d.mp3"].label == 1


def test_scan_dedupes_identical_files(tmp_path):
    good = tmp_path / "good"
    bad = tmp_path / "bad"
    good.mkdir()
    bad.mkdir()
    (good / "a.mp3").write_bytes(b"same")
    (good / "a_copy.mp3").write_bytes(b"same")
    (bad / "b.mp3").write_bytes(b"different")
    records = scan_labeled_dirs(str(good), str(bad), recursive=True)
    assert len(records) == 2


def test_split_is_deterministic_and_disjoint(tmp_path):
    good = tmp_path / "good"
    bad = tmp_path / "bad"
    good.mkdir()
    bad.mkdir()
    for index in range(10):
        (good / f"g{index}.mp3").write_bytes(f"good-{index}".encode())
        (bad / f"b{index}.mp3").write_bytes(f"bad-{index}".encode())
    records = scan_labeled_dirs(str(good), str(bad), recursive=False)
    train_a, eval_a = split_records(records, eval_fraction=0.3)
    train_b, eval_b = split_records(records, eval_fraction=0.3)
    assert {r.sha256 for r in eval_a} == {r.sha256 for r in eval_b}
    assert {r.sha256 for r in train_a}.isdisjoint({r.sha256 for r in eval_a})
    assert len(eval_a) > 0
    assert len(train_a) + len(eval_a) == len(records)
