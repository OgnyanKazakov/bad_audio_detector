from __future__ import annotations

import numpy as np


def frame_signal(x: np.ndarray, frame_size: int, hop_size: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    if frame_size <= 0 or hop_size <= 0:
        raise ValueError("frame_size and hop_size must be positive")
    if x.size < frame_size:
        x = np.pad(x, (0, frame_size - x.size))
    n_frames = 1 + int(np.ceil(max(0, x.size - frame_size) / hop_size))
    if n_frames <= 0:
        n_frames = 1
    needed = (n_frames - 1) * hop_size + frame_size
    if needed > x.size:
        x = np.pad(x, (0, needed - x.size))
    return np.lib.stride_tricks.sliding_window_view(x, frame_size)[::hop_size][:n_frames]
