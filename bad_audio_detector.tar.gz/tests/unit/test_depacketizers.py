from __future__ import annotations

import pytest

from bad_audio.io.rtp.depacketizer import depacketize, make_spec
from bad_audio.io.rtp.header import RtpPacket
from bad_audio.io.rtp.sdp import parse_sdp


def rtp(payload: bytes, *, pt: int = 0, ts: int = 1000) -> RtpPacket:
    return RtpPacket(
        version=2,
        padding=False,
        extension=False,
        csrc_count=0,
        marker=False,
        payload_type=pt,
        sequence=1,
        timestamp=ts,
        ssrc=1,
        payload=payload,
        payload_offset=12,
    )


def pack_bits(fields: list[tuple[int, int]]) -> bytes:
    value = 0
    nbits = 0
    for bits, width in fields:
        value = (value << width) | (bits & ((1 << width) - 1))
        nbits += width
    pad = (-nbits) % 8
    value <<= pad
    nbits += pad
    return value.to_bytes(nbits // 8, "big")


def test_g711_sample_based():
    frames = depacketize(rtp(b"\x00" * 160, pt=0), make_spec("PCMU"))
    assert len(frames) == 1
    assert frames[0].duration == 160
    assert frames[0].sample_rate == 8000
    assert frames[0].speech is True


def test_g722_clock_vs_sample_rate():
    frames = depacketize(rtp(b"\x00" * 80, pt=9), make_spec("G722"))
    assert frames[0].duration == 80
    assert frames[0].sample_rate == 16000


def test_g729_multiframe_and_cn():
    frames = depacketize(rtp(b"\x01" * 20, pt=18), make_spec("G729"))
    assert [f.rtp_timestamp for f in frames] == [1000, 1080]
    assert all(f.duration == 80 for f in frames)
    assert all(f.speech for f in frames)

    frames = depacketize(rtp(b"\x01" * 12, pt=18), make_spec("G729"))
    assert len(frames) == 2
    assert frames[0].speech is True
    assert frames[1].data == b""
    assert frames[1].valid is False


def test_amr_be_single_frame():
    payload = pack_bits([(15, 4), (0, 1), (7, 4), (1, 1), (0, 244)])
    frames = depacketize(rtp(payload, pt=97), make_spec("AMR-NB", octet_align=False))
    assert len(frames) == 1
    assert frames[0].codec == "AMR-NB"
    assert frames[0].duration == 160
    assert frames[0].data[0] == 0x3C
    assert len(frames[0].data) == 32


def test_amr_be_multiframe():
    payload = pack_bits(
        [(15, 4), (1, 1), (7, 4), (1, 1), (0, 1), (0, 4), (1, 1), (0, 244), (0, 95)]
    )
    frames = depacketize(rtp(payload, pt=97), make_spec("AMR-NB", octet_align=False))
    assert len(frames) == 2
    assert [f.rtp_timestamp for f in frames] == [1000, 1160]
    assert frames[0].frame_type == "speech"
    assert frames[1].frame_type == "speech"


def test_amr_oa_multiframe_with_crc():
    payload = bytes([0xF0, 0x3C | 0x80, 0x04, 0x00, 0x00]) + b"\x00" * 31 + b"\x00" * 12
    frames = depacketize(
        rtp(payload, pt=98),
        make_spec("AMR-NB", octet_align=True, amr_crc=True),
    )
    assert len(frames) == 2
    assert [f.rtp_timestamp for f in frames] == [1000, 1160]
    assert frames[0].data[0] == 0x3C
    assert frames[1].data[0] == 0x04


def test_amr_no_data_advances_timeline():
    payload = bytes([0x00, 0x78])  # CMR=0, F=0 FT=15 Q=0 P=0
    frames = depacketize(rtp(payload, pt=97), make_spec("AMR-NB", octet_align=True))
    assert len(frames) == 1
    assert frames[0].valid is False
    assert frames[0].duration == 160


def test_opus_duration():
    # config 1 = SILK NB 20 ms, frame count code 0 => one frame
    frames = depacketize(rtp(bytes([1 << 3]), pt=111), make_spec("OPUS"))
    assert len(frames) == 1
    assert frames[0].duration == 960
    assert frames[0].sample_rate == 48000


def test_l16():
    frames = depacketize(rtp(b"\x00" * 320, pt=96), make_spec("L16", rtp_clock_rate=8000))
    assert frames[0].duration == 160


def test_sdp_parsing_amr_octet_aligned_and_opus():
    sdp = """v=0
m=audio 49170 RTP/AVP 96 97 111 18
a=rtpmap:96 AMR-WB/16000/1
a=fmtp:96 octet-align=1; mode-set=0,1,2
a=rtpmap:97 AMR-NB/8000
a=fmtp:97 octet-align=0
a=rtpmap:111 opus/48000/2
a=rtpmap:18 G729/8000
"""
    specs = parse_sdp(sdp)
    assert specs[96].encoding == "AMR-WB"
    assert specs[96].octet_align is True
    assert specs[96].sample_rate == 16000
    assert specs[97].octet_align is False
    assert specs[111].encoding == "OPUS"
    assert specs[111].channels == 2
    assert specs[18].encoding == "G729"


def test_amr_interleaving_is_rejected():
    spec = make_spec("AMR-NB", octet_align=True, interleaving=True)
    with pytest.raises(NotImplementedError):
        depacketize(rtp(bytes([0xF0, 0x00]), pt=97), spec)


def test_payload_type_map_override():
    from bad_audio.config import Settings
    from bad_audio.pipeline import Detector
    from bad_audio.streaming.session import create_session

    settings = Settings(_env_file=None, payload_type_map='{"96": "AMR-WB"}')
    detector = Detector(model=None, settings=settings)
    session = create_session(detector, settings, {"format": "rtp", "payload_type": 96})
    assert session.spec is not None
    assert session.spec.encoding == "AMR-WB"
    assert session.spec.sample_rate == 16000
