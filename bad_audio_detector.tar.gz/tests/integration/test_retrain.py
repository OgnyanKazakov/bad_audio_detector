from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from bad_audio.data.dataset import ManifestRow, write_manifest
from bad_audio.data.synthetic import make_bad, make_good, save_mp3, synth_speech


@pytest.mark.slow
def test_retrain_from_mp3_dirs(tmp_path):
    good = tmp_path / "good"
    bad = tmp_path / "bad"
    good.mkdir()
    bad.mkdir()
    for index in range(12):
        source = synth_speech(1.0, seed=1000 + index)
        save_mp3(good / f"g{index}.mp3", make_good(source, "PCMU", 30.0, 0.0, index), bitrate=64000)
        save_mp3(bad / f"b{index}.mp3", make_bad(source, "PCMU", index), bitrate=64000)

    synthetic = tmp_path / "synthetic"
    (synthetic / "good").mkdir(parents=True)
    (synthetic / "bad").mkdir(parents=True)
    rows = []
    for index in range(20):
        source = synth_speech(1.0, seed=3000 + index)
        good_path = synthetic / "good" / f"g{index}.mp3"
        bad_path = synthetic / "bad" / f"b{index}.mp3"
        save_mp3(good_path, make_good(source, "PCMU", 30.0, 0.0, index), bitrate=64000)
        save_mp3(bad_path, make_bad(source, "PCMU", index), bitrate=64000)
        rows.append(ManifestRow(path=str(good_path.relative_to(synthetic)), label=0, source_id=f"s{index}"))
        rows.append(ManifestRow(path=str(bad_path.relative_to(synthetic)), label=1, source_id=f"s{index}"))
    write_manifest(synthetic / "manifest.csv", rows)
    out = tmp_path / "models"
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[2] / "src")
    result = subprocess.run(
        [
            sys.executable,
            "scripts/retrain_from_dirs.py",
            "--good-dir",
            str(good),
            "--bad-dir",
            str(bad),
            "--out-dir",
            str(out),
            "--synthetic-manifest",
            str(synthetic / "manifest.csv"),
            "--eval-fraction",
            "0.25",
        ],
        cwd=Path(__file__).resolve().parents[2],
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert (out / "current" / "detector.joblib").exists()
    assert (out / "current" / "metrics.json").exists()
    metrics = (out / "current" / "metrics.json").read_text()
    assert "recall" in metrics
