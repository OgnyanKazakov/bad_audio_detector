from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from .config import Settings, get_settings
from .detect.decision import decide
from .detect.model import DetectorModel, load_model
from .detect.rules import rules_score
from .dsp.aggregate import window_bounds
from .dsp.features import extract_features
from .io.audio import decode_audio_bytes
from .io.rtp.decoder import CodecDecoder
from .io.rtp.depacketizer import EncodedFrame
from .io.rtp.specs import CodecSpec


@dataclass
class WindowResult:
    start_s: float
    end_s: float
    p_incorrect: float
    insufficient: bool


@dataclass
class AnalysisResult:
    verdict: str
    confidence: float | None
    insufficient_signal: bool
    windows: list[WindowResult] = field(default_factory=list)
    evidence: dict[str, float] = field(default_factory=dict)
    model_version: str = "rules"
    latency_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "confidence": self.confidence,
            "insufficient_signal": self.insufficient_signal,
            "windows": [
                {
                    "start_s": round(w.start_s, 3),
                    "end_s": round(w.end_s, 3),
                    "p_incorrect": round(w.p_incorrect, 4),
                    "insufficient": w.insufficient,
                }
                for w in self.windows
            ],
            "evidence": {k: round(float(v), 6) for k, v in self.evidence.items()},
            "model_version": self.model_version,
            "latency_ms": round(self.latency_ms, 2),
        }


class Detector:
    def __init__(
        self,
        model: DetectorModel | None = None,
        settings: Settings | None = None,
        use_model: bool = False,
    ) -> None:
        self.settings = settings or get_settings()
        if model is None and use_model:
            model = load_model(self.settings.model_path)
        self.model = model
        self.decoder = CodecDecoder(target_rate=self.settings.target_sample_rate)

    @classmethod
    def from_settings(cls, settings: Settings | None = None) -> Detector:
        return cls(model=None, settings=settings, use_model=True)

    @property
    def threshold(self) -> float:
        if self.settings.threshold_override is not None:
            return float(self.settings.threshold_override)
        return self.model.threshold if self.model else self.settings.decision_threshold

    @property
    def model_version(self) -> str:
        return self.model.version if self.model else "rules"

    def _score(self, features: dict[str, float]) -> float:
        if features.get("insufficient_signal", 0.0) > 0.5:
            return 0.0
        if self.model is not None:
            return float(np.clip(self.model.score(features), 0.0, 1.0))
        return rules_score(features)

    def analyze_pcm(
        self, pcm: np.ndarray, valid_mask: np.ndarray | None = None
    ) -> AnalysisResult:
        started = time.perf_counter()
        sr = self.settings.target_sample_rate
        pcm = np.asarray(pcm, dtype=np.float32).reshape(-1)
        if valid_mask is None:
            valid_mask = np.ones(pcm.size, dtype=bool)
        else:
            valid_mask = np.asarray(valid_mask, dtype=bool).reshape(-1)
            if valid_mask.size != pcm.size:
                valid_mask = np.ones(pcm.size, dtype=bool)

        window_samples = max(1, int(self.settings.window_seconds * sr))
        hop_samples = max(1, int(self.settings.hop_seconds * sr))
        bounds = window_bounds(pcm.size, window_samples, hop_samples)

        windows: list[WindowResult] = []
        features_by_window: list[dict[str, float]] = []
        for start, end in bounds:
            pane = pcm[start:end]
            mask = valid_mask[start:end]
            features = extract_features(
                pane,
                valid_mask=mask,
                sample_rate=sr,
                min_active_seconds=min(self.settings.min_activity_seconds, len(pane) / sr / 2),
                vad_threshold=self.settings.vad_threshold,
            )
            score = self._score(features)
            features_by_window.append(features)
            windows.append(
                WindowResult(
                    start_s=start / sr,
                    end_s=end / sr,
                    p_incorrect=score,
                    insufficient=bool(features.get("insufficient_signal", 0.0) > 0.5),
                )
            )

        sufficient = [w for w in windows if not w.insufficient]
        insufficient_signal = not sufficient
        if insufficient_signal:
            result = AnalysisResult(
                verdict="correct_decoder",
                confidence=None,
                insufficient_signal=True,
                windows=windows,
                evidence=self._evidence(features_by_window[-1]) if features_by_window else {},
                model_version=self.model_version,
            )
        else:
            scores = [w.p_incorrect for w in sufficient]
            verdict = decide(
                scores,
                threshold=self.threshold,
                consecutive=self.settings.consecutive_windows,
            )
            max_score = max(scores)
            confidence = max_score if verdict == "incorrect_decoder" else 1.0 - max_score
            best_index = int(np.argmax([w.p_incorrect for w in windows]))
            result = AnalysisResult(
                verdict=verdict,
                confidence=float(np.clip(confidence, 0.0, 1.0)),
                insufficient_signal=False,
                windows=windows,
                evidence=self._evidence(features_by_window[best_index]),
                model_version=self.model_version,
            )
        result.latency_ms = (time.perf_counter() - started) * 1000.0
        return result

    def analyze_file(self, data: bytes, filename: str | None = None) -> AnalysisResult:
        return self.analyze_pcm(decode_audio_bytes(data, filename))

    def analyze_frames(self, frames: list[EncodedFrame], spec: CodecSpec) -> AnalysisResult:
        decoded = self.decoder.decode(frames, spec)
        return self.analyze_pcm(decoded.pcm, decoded.valid_mask)

    @staticmethod
    def _evidence(features: dict[str, float]) -> dict[str, float]:
        keys = (
            "flatness_mean",
            "hnr_mean",
            "voiced_fraction",
            "modulation_2_8",
            "flux_mean",
            "rolloff_norm_mean",
            "gap_fraction",
        )
        return {key: float(features.get(key, 0.0)) for key in keys}
