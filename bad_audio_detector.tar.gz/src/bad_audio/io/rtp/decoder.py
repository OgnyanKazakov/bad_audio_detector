from __future__ import annotations

from dataclasses import dataclass

import av
import numpy as np

from ..audio import resample
from ..rtp.depacketizer import EncodedFrame
from ..rtp.specs import CodecSpec


def _ulaw_table() -> np.ndarray:
    i = np.arange(256, dtype=np.int32)
    u = (~i) & 0xFF
    sign = u & 0x80
    exponent = (u >> 4) & 0x07
    mantissa = u & 0x0F
    sample = ((mantissa << 3) + 0x84) << exponent
    sample = sample - 0x84
    sample = np.where(sign, -sample, sample)
    return (sample.astype(np.float32) / 32768.0)


def _alaw_table() -> np.ndarray:
    i = np.arange(256, dtype=np.int32)
    a = i ^ 0x55
    sign = a & 0x80
    exponent = (a >> 4) & 0x07
    mantissa = a & 0x0F
    sample = np.where(
        exponent == 0,
        (mantissa << 4) + 8,
        ((mantissa << 4) + 0x108) << np.maximum(exponent - 1, 0),
    )
    sample = np.where(sign, -sample, sample)
    return (sample.astype(np.float32) / 32768.0)


ULAW_TABLE = _ulaw_table()
ALAW_TABLE = _alaw_table()


def ulaw_to_linear(data: np.ndarray) -> np.ndarray:
    return ULAW_TABLE[np.asarray(data, dtype=np.uint8)]


def alaw_to_linear(data: np.ndarray) -> np.ndarray:
    return ALAW_TABLE[np.asarray(data, dtype=np.uint8)]


@dataclass
class DecodedAudio:
    pcm: np.ndarray
    valid_mask: np.ndarray


class CodecDecoder:
    def __init__(self, target_rate: int = 16000) -> None:
        self.target_rate = target_rate

    def decode(self, frames: list[EncodedFrame], spec: CodecSpec) -> DecodedAudio:
        if not frames:
            return DecodedAudio(np.zeros(0, dtype=np.float32), np.zeros(0, dtype=bool))
        chunks: list[np.ndarray] = []
        masks: list[np.ndarray] = []
        group: list[EncodedFrame] = []

        def flush_group() -> None:
            if not group:
                return
            expected = sum(self._expected_samples(f, spec) for f in group)
            pcm = self._decode_group(group, spec)
            if len(pcm) < expected:
                pcm = np.pad(pcm, (0, expected - len(pcm)))
            elif len(pcm) > expected:
                pcm = pcm[:expected]
            chunks.append(pcm.astype(np.float32, copy=False))
            masks.append(np.ones(len(pcm), dtype=bool))
            group.clear()

        for item in frames:
            if not item.valid:
                flush_group()
                n = self._expected_samples(item, spec)
                chunks.append(np.zeros(n, dtype=np.float32))
                masks.append(np.zeros(n, dtype=bool))
            else:
                group.append(item)
        flush_group()

        if not chunks:
            return DecodedAudio(np.zeros(0, dtype=np.float32), np.zeros(0, dtype=bool))
        return DecodedAudio(
            np.concatenate(chunks).astype(np.float32, copy=False),
            np.concatenate(masks),
        )

    def _expected_samples(self, frame: EncodedFrame, spec: CodecSpec) -> int:
        rate = spec.rtp_clock_rate or spec.sample_rate
        return max(0, int(round(frame.duration * self.target_rate / rate)))

    def _decode_group(self, frames: list[EncodedFrame], spec: CodecSpec) -> np.ndarray:
        encoding = spec.encoding
        if encoding == "PCMU":
            raw = b"".join(f.data for f in frames)
            pcm = ulaw_to_linear(np.frombuffer(raw, dtype=np.uint8))
            return resample(pcm, spec.sample_rate, self.target_rate)
        if encoding == "PCMA":
            raw = b"".join(f.data for f in frames)
            pcm = alaw_to_linear(np.frombuffer(raw, dtype=np.uint8))
            return resample(pcm, spec.sample_rate, self.target_rate)
        if encoding == "L16":
            raw = b"".join(f.data for f in frames)
            pcm = np.frombuffer(raw, dtype=">i2").astype(np.float32) / 32768.0
            if spec.channels > 1:
                pcm = pcm.reshape(-1, spec.channels).mean(axis=1)
            return resample(pcm, spec.sample_rate, self.target_rate)
        return self._decode_with_av(frames, spec)

    def _decode_with_av(self, frames: list[EncodedFrame], spec: CodecSpec) -> np.ndarray:
        if not spec.decoder:
            return np.zeros(0, dtype=np.float32)
        try:
            codec = av.CodecContext.create(spec.decoder, "r")
        except Exception:
            return np.zeros(0, dtype=np.float32)
        try:
            codec.sample_rate = spec.sample_rate
            codec.layout = "mono"
        except Exception:
            pass
        resampler = av.AudioResampler(format="flt", layout="mono", rate=self.target_rate)
        chunks: list[np.ndarray] = []
        for item in frames:
            try:
                decoded = codec.decode(av.Packet(item.data))
            except Exception:
                continue
            for frame in decoded:
                for out in resampler.resample(frame):
                    chunks.append(out.to_ndarray().reshape(-1))
        try:
            for frame in codec.decode(None):
                for out in resampler.resample(frame):
                    chunks.append(out.to_ndarray().reshape(-1))
        except Exception:
            pass
        try:
            for out in resampler.resample(None):
                chunks.append(out.to_ndarray().reshape(-1))
        except Exception:
            pass
        if not chunks:
            return np.zeros(0, dtype=np.float32)
        return np.concatenate(chunks).astype(np.float32, copy=False)
