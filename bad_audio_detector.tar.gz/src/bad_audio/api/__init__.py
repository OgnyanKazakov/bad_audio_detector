"""HTTP and WebSocket API."""
