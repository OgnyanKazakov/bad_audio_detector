from __future__ import annotations

from .base import Depacketizer, EncodedFrame


class ILBCDepacketizer(Depacketizer):
    DURATIONS = {38: 160, 50: 240}

    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        if not packet.payload:
            return []
        if len(packet.payload) not in self.DURATIONS:
            raise ValueError("invalid iLBC payload length")
        return [
            EncodedFrame(
                codec=spec.encoding,
                data=packet.payload,
                rtp_timestamp=packet.timestamp,
                duration=self.DURATIONS[len(packet.payload)],
                sample_rate=spec.sample_rate,
                sequence=packet.sequence,
            )
        ]
