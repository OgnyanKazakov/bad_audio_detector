from __future__ import annotations

import io

import numpy as np
import soundfile as sf

from bad_audio.io.audio import decode_audio_bytes, read_pcm, resample


def sine(sr: int, seconds: float = 1.0, freq: float = 440.0) -> np.ndarray:
    t = np.arange(int(sr * seconds)) / sr
    return (0.2 * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_resample_length_and_energy():
    x = sine(8000)
    y = resample(x, 8000, 16000)
    assert y.shape == (16000,)
    assert abs(float(np.sqrt(np.mean(y**2))) - float(np.sqrt(np.mean(x**2)))) < 0.02


def test_decode_wav_to_16k_mono():
    x = sine(8000, 0.5)
    buf = io.BytesIO()
    sf.write(buf, x, 8000, format="WAV")
    y = decode_audio_bytes(buf.getvalue(), "test.wav")
    assert y.dtype == np.float32
    assert y.ndim == 1
    assert abs(len(y) - 8000) < 10


def test_decode_mp3_to_16k():
    import av

    x = sine(16000, 0.5)
    pcm = (x * 32767).astype(np.int16)
    buf = io.BytesIO()
    container = av.open(buf, mode="w", format="mp3")
    stream = container.add_stream("mp3", rate=16000)
    stream.layout = "mono"
    frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
    frame.sample_rate = 16000
    for packet in stream.encode(frame):
        container.mux(packet)
    for packet in stream.encode(None):
        container.mux(packet)
    container.close()
    y = decode_audio_bytes(buf.getvalue(), "test.mp3")
    assert len(y) > 1000


def test_read_pcm_s16le_and_resample():
    x = sine(8000, 0.25)
    data = (x * 32767).astype("<i2").tobytes()
    y = read_pcm(data, sample_rate=8000, fmt="s16le")
    assert y.dtype == np.float32
    assert len(y) == 4000
