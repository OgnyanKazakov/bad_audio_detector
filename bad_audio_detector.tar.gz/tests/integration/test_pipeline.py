from __future__ import annotations

import io

import numpy as np

from bad_audio.pipeline import Detector


def sine(sr: int, seconds: float, freq: float = 440.0, amp: float = 0.2) -> np.ndarray:
    t = np.arange(int(sr * seconds)) / sr
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_pipeline_tone_is_correct_with_rules():
    result = Detector(model=None).analyze_pcm(sine(16000, 2.0))
    assert result.verdict == "correct_decoder"
    assert result.insufficient_signal is False
    assert result.confidence is not None


def test_pipeline_noise_is_incorrect_with_rules():
    rng = np.random.default_rng(2)
    result = Detector(model=None).analyze_pcm(
        (0.2 * rng.standard_normal(32000)).astype(np.float32)
    )
    assert result.verdict == "incorrect_decoder"


def test_pipeline_silence_is_insufficient():
    result = Detector(model=None).analyze_pcm(np.zeros(32000, dtype=np.float32))
    assert result.verdict == "correct_decoder"
    assert result.insufficient_signal is True
    assert result.confidence is None


def test_pipeline_analyze_mp3():
    import av

    x = sine(16000, 2.0)
    pcm = (x * 32767).astype(np.int16)
    buf = io.BytesIO()
    container = av.open(buf, mode="w", format="mp3")
    stream = container.add_stream("mp3", rate=16000)
    stream.layout = "mono"
    frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
    frame.sample_rate = 16000
    for packet in stream.encode(frame):
        container.mux(packet)
    for packet in stream.encode(None):
        container.mux(packet)
    container.close()
    result = Detector(model=None).analyze_file(buf.getvalue(), "tone.mp3")
    assert result.verdict == "correct_decoder"
    assert result.insufficient_signal is False
