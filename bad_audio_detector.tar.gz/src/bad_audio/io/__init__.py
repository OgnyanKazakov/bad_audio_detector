"""I/O adapters."""
