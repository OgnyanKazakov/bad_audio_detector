from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_mode: str = "dev"
    ingest_mode: str = "file"
    rtp_decode: bool = True
    target_sample_rate: int = 16000
    window_seconds: float = 1.0
    hop_seconds: float = 0.5
    decision_threshold: float = 0.5
    threshold_override: float | None = None
    consecutive_windows: int = 2
    min_activity_seconds: float = 0.5
    vad_threshold: float = 0.02

    model_path: str = "models/current/detector.joblib"
    models_dir: str = "models"
    threshold_path: str = "models/current/threshold.json"

    good_records_dir: str = "/data/records/good"
    bad_records_dir: str = "/data/records/bad"
    records_recursive: bool = True
    real_eval_fraction: float = 0.2
    real_data_weight: float = 1.0
    min_recall: float = 0.98
    min_precision: float = 0.85

    admin_token: str = ""
    jitter_buffer_ms: int = 200
    max_frames_per_packet: int = 10
    payload_type_map: str = ""

    max_upload_mb: int = 50


@lru_cache
def get_settings() -> Settings:
    return Settings()
