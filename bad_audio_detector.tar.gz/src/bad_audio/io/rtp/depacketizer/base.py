from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class EncodedFrame:
    codec: str
    data: bytes
    rtp_timestamp: int
    duration: int
    sample_rate: int
    channels: int = 1
    valid: bool = True
    speech: bool = True
    frame_type: str = "speech"
    sequence: int = 0


class Depacketizer:
    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        raise NotImplementedError
