from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..dsp.features import FEATURE_NAMES, extract_features, feature_vector
from ..io.audio import decode_audio_bytes


@dataclass
class ManifestRow:
    path: str
    label: int
    codec: str = "unknown"
    source_id: str = ""
    mode: str = "dev"
    snr: float = 60.0
    loss: float = 0.0
    weight: float = 1.0


def read_manifest(path: str | Path) -> list[ManifestRow]:
    rows: list[ManifestRow] = []
    base = Path(path).resolve().parent
    with Path(path).open(newline="", encoding="utf-8") as handle:
        for item in csv.DictReader(handle):
            rows.append(
                ManifestRow(
                    path=str((base / item["path"]).resolve()) if not Path(item["path"]).is_absolute() else item["path"],
                    label=int(item["label"]),
                    codec=item.get("codec", "unknown"),
                    source_id=item.get("source_id", ""),
                    mode=item.get("mode", "dev"),
                    snr=float(item.get("snr", 60.0) or 60.0),
                    loss=float(item.get("loss", 0.0) or 0.0),
                    weight=float(item.get("weight", 1.0) or 1.0),
                )
            )
    return rows


def write_manifest(path: str | Path, rows: list[ManifestRow]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["path", "label", "codec", "source_id", "mode", "snr", "loss", "weight"])
        for row in rows:
            writer.writerow(
                [row.path, row.label, row.codec, row.source_id, row.mode, row.snr, row.loss, row.weight]
            )


def features_for_path(path: str | Path) -> np.ndarray | None:
    try:
        data = Path(path).read_bytes()
        pcm = decode_audio_bytes(data, str(path))
    except Exception:
        return None
    if pcm.size == 0:
        return None
    return feature_vector(extract_features(pcm))


def build_matrix(
    rows: list[ManifestRow], verbose: bool = False
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[ManifestRow]]:
    features: list[np.ndarray] = []
    labels: list[int] = []
    weights: list[float] = []
    kept: list[ManifestRow] = []
    for index, row in enumerate(rows):
        vector = features_for_path(row.path)
        if vector is None:
            if verbose:
                print(f"skip unreadable: {row.path}")
            continue
        features.append(vector)
        labels.append(int(row.label))
        weights.append(float(row.weight))
        kept.append(row)
        if verbose and (index + 1) % 25 == 0:
            print(f"extracted {index + 1}/{len(rows)}")
    if not features:
        return (
            np.zeros((0, len(FEATURE_NAMES)), dtype=np.float32),
            np.zeros(0, dtype=np.int64),
            np.zeros(0, dtype=np.float32),
            [],
        )
    return (
        np.vstack(features).astype(np.float32),
        np.asarray(labels, dtype=np.int64),
        np.asarray(weights, dtype=np.float32),
        kept,
    )
