"""Dataset generation and labeled data tooling."""
