# Bad Audio Detector — Design

**Date:** 2026-10-21
**Status:** Approved for implementation

## Goal

A codec-agnostic service that decides whether call audio is intact
(`correct_decoder`) or was destroyed by a wrong codec/decoder
(`incorrect_decoder`). Development input is MP3; production input is PCM or
RTP over WebSocket. Only catastrophic corruption is in scope.

## Decisions

- Detection is a binary speech-integrity decision, not codec identification.
- Internal format: mono float32, 16 kHz.
- Features: spectral shape/flatness/flux/entropy/crest, band ratios,
  autocorrelation pitch/HNR/voicing, LPC envelope proxy, 2–8 Hz modulation,
  spectral holes/band edge; aggregated per 1 s window.
- Classifier: HistGradientBoosting (fallback: rules).
- Threshold favors recall: target recall >= 0.98 at precision >= 0.85.
- Dev/calibration data: `.mp3` files in `GOOD_RECORDS_DIR` and
  `BAD_RECORDS_DIR`.
- Prod ingestion: RTP with RFC 3550 parsing, jitter buffer, pluggable codec
  depacketizers, multiframe support, AMR bandwidth-efficient and octet-aligned
  (RFC 4867), G.729 multiframe, G.722 clock-rate handling, Opus.
- Packet loss, reordering, DTX/SID are not corruption; gap masks exclude them.
- Model artifacts are versioned; retraining is offline and guarded by
  recall/precision floors. Admin reload is token-protected.

## Architecture

```
POST /v1/analyze        MP3/WAV/PCM file -> JSON verdict
WS   /v1/stream         config + PCM/RTP binary frames -> window verdicts

RTP -> header -> jitter/reorder/dedup -> codec registry -> depacketizer
    -> decoder -> gap mask -> 16 kHz PCM -> features -> windows
    -> classifier -> smoothing/hysteresis -> verdict
```

## Out of scope (v1)

- Subtle mismatches (A-law vs µ-law, bandwidth-only mismatch).
- Interleaved/robust-sorted AMR reconstruction (detected and rejected).
- Automatic retraining inside the service.
- Codec identification output.

## Acceptance

- AMR BE/OA with 1–N frames/packet, G.729 multiframe, G.722 clock handling.
- Packet loss/reorder/DTMF/SID do not trigger `incorrect_decoder`.
- MP3 good/bad folders drive threshold calibration and retraining without code
  changes; retrained models are evaluated on a held-out split and versioned.
- Recall >= 0.98 at precision >= 0.85 on synthetic MP3 held-out data.
- p95 < 50 ms per 1 s window on one CPU core.
