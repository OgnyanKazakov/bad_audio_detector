#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupShuffleSplit, train_test_split

from bad_audio.config import get_settings
from bad_audio.data.dataset import build_matrix, read_manifest
from bad_audio.detect.metrics import binary_metrics, choose_threshold
from bad_audio.detect.model import build_default_model, save_model
from bad_audio.dsp.features import FEATURE_NAMES


def split_rows(rows, test_size: float, seed: int):
    groups = [row.source_id or row.path for row in rows]
    if len(set(groups)) > 1:
        splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
        train_idx, test_idx = next(splitter.split(rows, groups=groups))
    else:
        idx = np.arange(len(rows))
        train_idx, test_idx = train_test_split(idx, test_size=test_size, random_state=seed)
    return [rows[i] for i in train_idx], [rows[i] for i in test_idx]


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the corruption detector")
    parser.add_argument("--manifest", default="data/synthetic/manifest.csv")
    parser.add_argument("--out", default=None)
    parser.add_argument("--metrics-out", default=None)
    parser.add_argument("--test-size", type=float, default=0.25)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--min-precision", type=float, default=None)
    parser.add_argument("--min-recall", type=float, default=None)
    parser.add_argument("--allow-below-target", action="store_true")
    args = parser.parse_args()

    settings = get_settings()
    out = args.out or settings.model_path
    metrics_out = args.metrics_out or str(Path(out).parent / "metrics.json")
    min_precision = args.min_precision if args.min_precision is not None else settings.min_precision
    min_recall = args.min_recall if args.min_recall is not None else settings.min_recall

    rows = read_manifest(args.manifest)
    if not rows:
        raise SystemExit("empty manifest")
    train_rows, test_rows = split_rows(rows, args.test_size, args.seed)
    print(f"train rows: {len(train_rows)}, test rows: {len(test_rows)}")
    X_train, y_train, w_train, _ = build_matrix(train_rows, verbose=True)
    X_test, y_test, _, test_kept = build_matrix(test_rows, verbose=True)
    if len(X_train) == 0 or len(X_test) == 0:
        raise SystemExit("not enough readable audio")

    classes, counts = np.unique(y_train, return_counts=True)
    class_weight = {int(c): len(y_train) / (len(classes) * n) for c, n in zip(classes, counts)}
    sample_weight = w_train * np.asarray([class_weight[int(y)] for y in y_train], dtype=np.float32)

    model = build_default_model()
    model.fit(X_train, y_train, sample_weight=sample_weight)
    scores = model.predict_proba(X_test)[:, 1]
    threshold = choose_threshold(y_test, scores, min_precision, min_recall)
    metrics = binary_metrics(y_test, scores, threshold)
    metrics["feature_count"] = len(FEATURE_NAMES)
    metrics["train_rows"] = int(len(X_train))
    metrics["test_rows"] = int(len(X_test))
    metrics["manifest"] = str(Path(args.manifest).resolve())

    per_codec = {}
    for codec in sorted({r.codec for r in test_kept}):
        mask = np.asarray([r.codec == codec for r in test_kept])
        if mask.sum() and len(np.unique(y_test[mask])) > 1:
            per_codec[codec] = binary_metrics(y_test[mask], scores[mask], threshold)
    metrics["per_codec"] = per_codec

    print(json.dumps(metrics, indent=2))
    meets = metrics["recall"] >= min_recall and metrics["precision"] >= min_precision
    if not meets and not args.allow_below_target:
        raise SystemExit(
            f"model below target: recall={metrics['recall']:.3f} precision={metrics['precision']:.3f}"
        )

    version = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    save_model(out, model, FEATURE_NAMES, threshold=threshold, version=version)
    Path(metrics_out).parent.mkdir(parents=True, exist_ok=True)
    Path(metrics_out).write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    threshold_path = Path(out).resolve().parent / "threshold.json"
    threshold_path.write_text(json.dumps({"threshold": threshold}, indent=2), encoding="utf-8")
    print(f"saved model: {out} (threshold={threshold:.4f})")


if __name__ == "__main__":
    main()
