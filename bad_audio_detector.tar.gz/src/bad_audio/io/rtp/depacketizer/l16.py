from __future__ import annotations

from .base import Depacketizer, EncodedFrame


class L16Depacketizer(Depacketizer):
    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        if not packet.payload:
            return []
        samples = len(packet.payload) // (2 * max(1, spec.channels))
        return [
            EncodedFrame(
                codec=spec.encoding,
                data=packet.payload,
                rtp_timestamp=packet.timestamp,
                duration=samples,
                sample_rate=spec.sample_rate,
                channels=spec.channels,
                sequence=packet.sequence,
            )
        ]
