#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from bad_audio.config import get_settings
from bad_audio.data.dataset import ManifestRow, build_matrix, read_manifest
from bad_audio.data.labeled_dirs import scan_labeled_dirs, split_records
from bad_audio.detect.metrics import binary_metrics, choose_threshold
from bad_audio.detect.model import build_default_model, save_model
from bad_audio.dsp.features import FEATURE_NAMES


def _weights(y: np.ndarray, base: np.ndarray) -> np.ndarray:
    classes, counts = np.unique(y, return_counts=True)
    class_weight = {int(c): len(y) / (len(classes) * n) for c, n in zip(classes, counts)}
    return base * np.asarray([class_weight[int(label)] for label in y], dtype=np.float32)


def retrain(
    good_dir: str,
    bad_dir: str,
    out_dir: str = "models",
    synthetic_manifest: str | None = None,
    real_weight: float = 1.0,
    eval_fraction: float = 0.2,
    min_precision: float = 0.85,
    min_recall: float = 0.98,
    recursive: bool = True,
    seed: int = 0,
) -> dict:
    records = scan_labeled_dirs(good_dir, bad_dir, recursive=recursive)
    if not records:
        raise SystemExit("no MP3 files found in the labeled folders")
    train_records, eval_records = split_records(records, eval_fraction)
    if not train_records or not eval_records:
        raise SystemExit(
            "not enough records for a train/eval split; add more MP3s or lower --eval-fraction"
        )

    train_rows = [
        ManifestRow(
            path=str(r.path),
            label=r.label,
            codec="real",
            source_id=r.sha256,
            weight=real_weight,
        )
        for r in train_records
    ]
    eval_rows = [
        ManifestRow(path=str(r.path), label=r.label, codec="real", source_id=r.sha256)
        for r in eval_records
    ]
    synthetic_rows: list[ManifestRow] = []
    if synthetic_manifest:
        synthetic_rows = read_manifest(synthetic_manifest)
        rng = np.random.default_rng(seed)
        for row in synthetic_rows:
            row.weight = 1.0
        rng.shuffle(synthetic_rows)

    X_train, y_train, w_train, _ = build_matrix(train_rows + synthetic_rows, verbose=True)
    X_eval, y_eval, _, eval_kept = build_matrix(eval_rows, verbose=True)
    if len(X_train) == 0 or len(X_eval) == 0:
        raise SystemExit("not enough readable audio")

    model = build_default_model()
    model.fit(X_train, y_train, sample_weight=_weights(y_train, w_train))
    scores = model.predict_proba(X_eval)[:, 1]
    threshold = choose_threshold(y_eval, scores, min_precision, min_recall)
    metrics = binary_metrics(y_eval, scores, threshold)
    metrics.update(
        {
            "train_rows": int(len(X_train)),
            "eval_rows": int(len(X_eval)),
            "real_train": len(train_rows),
            "real_eval": len(eval_rows),
            "synthetic_train": len(synthetic_rows),
            "feature_count": len(FEATURE_NAMES),
            "good_dir": str(Path(good_dir).resolve()),
            "bad_dir": str(Path(bad_dir).resolve()),
        }
    )
    per_codec = {}
    for label in sorted({r.label for r in eval_kept}):
        mask = np.asarray([r.label == label for r in eval_kept])
        name = "correct_decoder" if label == 0 else "incorrect_decoder"
        per_codec[name] = int(mask.sum())
    metrics["eval_label_counts"] = per_codec

    meets = metrics["recall"] >= min_recall and metrics["precision"] >= min_precision
    if not meets:
        raise SystemExit(
            "retrained model below target: "
            f"recall={metrics['recall']:.3f} precision={metrics['precision']:.3f}. "
            "Add more real records or review the features."
        )

    version = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    root = Path(out_dir)
    version_dir = root / f"detector-{version}"
    version_dir.mkdir(parents=True, exist_ok=True)
    model_path = version_dir / "detector.joblib"
    save_model(str(model_path), model, FEATURE_NAMES, threshold=threshold, version=version)
    (version_dir / "threshold.json").write_text(
        json.dumps({"threshold": threshold}, indent=2), encoding="utf-8"
    )
    (version_dir / "metadata.json").write_text(
        json.dumps({"version": version, "metrics": metrics}, indent=2), encoding="utf-8"
    )

    current = root / "current"
    current.mkdir(parents=True, exist_ok=True)
    shutil.copy2(model_path, current / "detector.joblib")
    shutil.copy2(version_dir / "threshold.json", current / "threshold.json")
    shutil.copy2(version_dir / "metadata.json", current / "metrics.json")
    print(json.dumps({"version": version, "metrics": metrics}, indent=2))
    print(f"published {current / 'detector.joblib'}")
    return {"version": version, "metrics": metrics, "model_path": str(current / "detector.joblib")}


def main() -> None:
    parser = argparse.ArgumentParser(description="Retrain from good/bad MP3 folders")
    parser.add_argument("--good-dir", default=None)
    parser.add_argument("--bad-dir", default=None)
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--synthetic-manifest", default=None)
    parser.add_argument("--real-weight", type=float, default=None)
    parser.add_argument("--eval-fraction", type=float, default=None)
    parser.add_argument("--min-precision", type=float, default=None)
    parser.add_argument("--min-recall", type=float, default=None)
    parser.add_argument("--no-recursive", action="store_true")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    settings = get_settings()
    good_dir = args.good_dir or settings.good_records_dir
    bad_dir = args.bad_dir or settings.bad_records_dir
    out_dir = args.out_dir or settings.models_dir
    synthetic_path = args.synthetic_manifest
    if synthetic_path is None and Path("data/synthetic/manifest.csv").exists():
        synthetic_path = "data/synthetic/manifest.csv"
    synthetic = synthetic_path if synthetic_path and Path(synthetic_path).exists() else None
    retrain(
        good_dir,
        bad_dir,
        out_dir=out_dir,
        synthetic_manifest=synthetic,
        real_weight=args.real_weight if args.real_weight is not None else settings.real_data_weight,
        eval_fraction=args.eval_fraction if args.eval_fraction is not None else settings.real_eval_fraction,
        min_precision=args.min_precision if args.min_precision is not None else settings.min_precision,
        min_recall=args.min_recall if args.min_recall is not None else settings.min_recall,
        recursive=not args.no_recursive and settings.records_recursive,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()
