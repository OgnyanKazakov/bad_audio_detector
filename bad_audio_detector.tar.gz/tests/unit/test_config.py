from __future__ import annotations

from bad_audio.config import Settings, get_settings


def test_settings_defaults(monkeypatch):
    for key in (
        "APP_MODE",
        "INGEST_MODE",
        "WINDOW_SECONDS",
        "HOP_SECONDS",
        "DECISION_THRESHOLD",
        "MODEL_PATH",
        "GOOD_RECORDS_DIR",
        "BAD_RECORDS_DIR",
    ):
        monkeypatch.delenv(key, raising=False)
    settings = Settings(_env_file=None)
    assert settings.app_mode == "dev"
    assert settings.ingest_mode == "file"
    assert settings.target_sample_rate == 16000
    assert settings.window_seconds == 1.0
    assert settings.hop_seconds == 0.5
    assert settings.decision_threshold == 0.5
    assert settings.consecutive_windows == 2
    assert settings.good_records_dir == "/data/records/good"
    assert settings.bad_records_dir == "/data/records/bad"


def test_settings_from_env(monkeypatch):
    monkeypatch.setenv("APP_MODE", "prod")
    monkeypatch.setenv("WINDOW_SECONDS", "2.0")
    monkeypatch.setenv("DECISION_THRESHOLD", "0.7")
    monkeypatch.setenv("GOOD_RECORDS_DIR", "/tmp/good")
    settings = Settings(_env_file=None)
    assert settings.app_mode == "prod"
    assert settings.window_seconds == 2.0
    assert settings.decision_threshold == 0.7
    assert settings.good_records_dir == "/tmp/good"
    assert get_settings() is get_settings()
