from __future__ import annotations

import struct
from dataclasses import dataclass

_HEADER = struct.Struct("!BBHII")


@dataclass(frozen=True, slots=True)
class RtpPacket:
    version: int
    padding: bool
    extension: bool
    csrc_count: int
    marker: bool
    payload_type: int
    sequence: int
    timestamp: int
    ssrc: int
    payload: bytes
    payload_offset: int


def parse_rtp(data: bytes) -> RtpPacket:
    if len(data) < _HEADER.size:
        raise ValueError("RTP packet shorter than fixed header")
    b0, b1, seq, ts, ssrc = _HEADER.unpack_from(data, 0)
    version = b0 >> 6
    if version != 2:
        raise ValueError(f"unsupported RTP version {version}")
    padding = bool(b0 & 0x20)
    extension = bool(b0 & 0x10)
    csrc_count = b0 & 0x0F
    marker = bool(b1 & 0x80)
    pt = b1 & 0x7F

    offset = _HEADER.size + 4 * csrc_count
    if len(data) < offset:
        raise ValueError("truncated RTP CSRC list")

    if extension:
        if len(data) < offset + 4:
            raise ValueError("truncated RTP extension header")
        _, words = struct.unpack_from("!HH", data, offset)
        offset += 4 + 4 * words
        if len(data) < offset:
            raise ValueError("truncated RTP extension data")

    end = len(data)
    if padding:
        if offset >= end:
            raise ValueError("RTP padding flag without padding")
        pad = data[-1]
        if pad == 0 or pad > end - offset:
            raise ValueError("invalid RTP padding length")
        end -= pad

    return RtpPacket(
        version=version,
        padding=padding,
        extension=extension,
        csrc_count=csrc_count,
        marker=marker,
        payload_type=pt,
        sequence=seq,
        timestamp=ts,
        ssrc=ssrc,
        payload=data[offset:end],
        payload_offset=offset,
    )
