#!/usr/bin/env python3
from __future__ import annotations

import argparse
import random
from pathlib import Path

import numpy as np

from bad_audio.data.dataset import ManifestRow, write_manifest
from bad_audio.data.synthetic import (
    CODECS,
    SR,
    continuous_single_tone,
    continuous_tone,
    make_bad,
    make_good,
    pad_silence,
    save_mp3,
    save_wav,
    synth_speech,
    tone_source,
)
from bad_audio.io.audio import decode_audio_bytes

AUDIO_EXTS = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}


def load_sources(directory: str | None, seconds: float) -> list[np.ndarray]:
    if not directory:
        return []
    out = []
    for path in sorted(Path(directory).rglob("*")):
        if path.suffix.lower() not in AUDIO_EXTS:
            continue
        try:
            pcm = decode_audio_bytes(path.read_bytes(), str(path))
        except Exception:
            continue
        target = int(seconds * SR)
        if len(pcm) < target:
            pcm = np.pad(pcm, (0, target - len(pcm)))
        else:
            start = random.randint(0, len(pcm) - target)
            pcm = pcm[start : start + target]
        if np.max(np.abs(pcm)) > 0:
            out.append(pcm.astype(np.float32))
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic MP3 good/bad call audio")
    parser.add_argument("--out", default="data/synthetic")
    parser.add_argument("--samples", type=int, default=120, help="samples per class")
    parser.add_argument("--seconds", type=float, default=3.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--source-dir", default=None)
    parser.add_argument("--codecs", default="PCMU,PCMA,G722,AMR-NB,OPUS,MP3")
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    out = Path(args.out)
    (out / "good").mkdir(parents=True, exist_ok=True)
    (out / "bad").mkdir(parents=True, exist_ok=True)

    sources = load_sources(args.source_dir, args.seconds)
    codecs = [c.strip().upper() for c in args.codecs.split(",") if c.strip()]
    valid_codecs = [c for c in codecs if c in CODECS]
    if not valid_codecs:
        raise SystemExit("no valid codecs selected")

    rows: list[ManifestRow] = []
    for index in range(args.samples):
        is_tone_source = False
        if sources:
            source = sources[index % len(sources)]
            source_id = f"file-{index % len(sources):05d}"
        elif index % 7 == 0:
            source = tone_source(args.seconds, seed=args.seed * 100003 + index)
            source_id = f"tones-{args.seed}-{index:05d}"
            is_tone_source = True
        elif index % 11 == 0:
            source = continuous_tone(args.seconds, seed=args.seed * 100003 + index)
            source_id = f"ctones-{args.seed}-{index:05d}"
            is_tone_source = True
        elif index % 13 == 0:
            source = continuous_single_tone(args.seconds, seed=args.seed * 100003 + index)
            source_id = f"single-{args.seed}-{index:05d}"
            is_tone_source = True
        elif index % 17 == 0:
            source = continuous_single_tone(
                args.seconds, seed=args.seed * 100003 + index, fixed=True
            )
            source_id = f"tone1k-{args.seed}-{index:05d}"
            is_tone_source = True
        else:
            source = synth_speech(args.seconds, seed=args.seed * 100003 + index)
            source_id = f"synth-{args.seed}-{index:05d}"
        if not is_tone_source or index % 5 == 0:
            source = pad_silence(source, seed=args.seed * 100003 + index)

        codec = random.choice(valid_codecs)
        snr = random.choice([60.0, 30.0, 20.0, 10.0])
        loss = random.choice([0.0, 0.0, 0.01, 0.03])
        good = make_good(source, codec, snr, loss, seed=index, extra_tones=not is_tone_source)
        bad = make_bad(source, codec, seed=index)

        bitrate = random.choice([64000, 128000])
        use_wav = index % 3 == 0
        suffix = "wav" if use_wav else "mp3"
        good_path = out / "good" / f"good_{index:05d}.{suffix}"
        bad_path = out / "bad" / f"bad_{index:05d}.{suffix}"
        if use_wav:
            save_wav(good_path, good)
            save_wav(bad_path, bad)
        else:
            save_mp3(good_path, good, bitrate=bitrate)
            save_mp3(bad_path, bad, bitrate=bitrate)
        rows.append(
            ManifestRow(
                path=str(good_path.relative_to(out)),
                label=0,
                codec=codec,
                source_id=source_id,
                mode="dev",
                snr=snr,
                loss=loss,
            )
        )
        rows.append(
            ManifestRow(
                path=str(bad_path.relative_to(out)),
                label=1,
                codec=codec,
                source_id=source_id,
                mode="dev",
                snr=snr,
                loss=loss,
            )
        )
        print(f"generated {index + 1}/{args.samples} ({codec})")

    write_manifest(out / "manifest.csv", rows)
    print(f"manifest: {out / 'manifest.csv'} ({len(rows)} rows)")


if __name__ == "__main__":
    main()
