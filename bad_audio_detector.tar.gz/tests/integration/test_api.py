from __future__ import annotations

import io
import struct

import numpy as np
import soundfile as sf
from fastapi.testclient import TestClient

from bad_audio.api.app import app
from bad_audio.pipeline import Detector


def sine(sr: int, seconds: float, freq: float = 440.0, amp: float = 0.2) -> np.ndarray:
    t = np.arange(int(sr * seconds)) / sr
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def wav_bytes(x: np.ndarray, sr: int) -> bytes:
    buf = io.BytesIO()
    sf.write(buf, x, sr, format="WAV")
    return buf.getvalue()


def make_rtp(payload: bytes, seq: int = 1, ts: int = 0, pt: int = 0) -> bytes:
    return struct.pack("!BBHII", 0x80, pt, seq, ts, 1) + payload


def setup_module() -> None:
    app.state.detector = Detector(model=None)


def test_healthz():
    with TestClient(app) as client:
        assert client.get("/healthz").status_code == 200
        assert client.get("/readyz").status_code == 200


def test_analyze_wav_tone_and_noise():
    with TestClient(app) as client:
        good = wav_bytes(sine(16000, 2.0), 16000)
        response = client.post(
            "/v1/analyze",
            files={"file": ("tone.wav", good, "audio/wav")},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["verdict"] == "correct_decoder"
        assert body["insufficient_signal"] is False

        rng = np.random.default_rng(4)
        bad = wav_bytes((0.2 * rng.standard_normal(32000)).astype(np.float32), 16000)
        response = client.post(
            "/v1/analyze",
            files={"file": ("noise.wav", bad, "audio/wav")},
        )
        assert response.status_code == 200, response.text
        assert response.json()["verdict"] == "incorrect_decoder"


def test_websocket_pcm_stream():
    with TestClient(app) as client:
        with client.websocket_connect("/v1/stream") as ws:
            assert ws.receive_json()["type"] == "ready"
            ws.send_json({"type": "config", "format": "pcm", "sample_rate": 16000, "pcm_format": "s16le"})
            pcm = (sine(16000, 3.0) * 32767).astype("<i2").tobytes()
            ws.send_bytes(pcm[: len(pcm) // 2])
            ws.send_bytes(pcm[len(pcm) // 2 :])
            ws.send_json({"type": "eos"})
            messages = []
            while True:
                message = ws.receive_json()
                messages.append(message)
                if message["type"] in ("verdict", "error"):
                    break
            assert messages[-1]["type"] == "verdict"
            assert messages[-1]["verdict"] == "correct_decoder"


def test_websocket_rtp_pcmu_stream():
    with TestClient(app) as client:
        with client.websocket_connect("/v1/stream") as ws:
            assert ws.receive_json()["type"] == "ready"
            ws.send_json(
                {
                    "type": "config",
                    "format": "rtp",
                    "payload_type": 0,
                    "codec": "PCMU",
                    "clock_rate": 8000,
                }
            )
            # 2 seconds of PCMU silence, 20 ms packets.
            for index in range(100):
                ws.send_bytes(make_rtp(b"\xff" * 160, seq=index, ts=index * 160))
            ws.send_json({"type": "eos"})
            while True:
                message = ws.receive_json()
                if message["type"] in ("verdict", "error"):
                    break
            assert message["type"] == "verdict"
            assert message["insufficient_signal"] is True


def pcmu_payloads(x: np.ndarray, sr: int = 8000) -> list[bytes]:
    import av

    pcm = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    enc = av.CodecContext.create("pcm_mulaw", "w")
    enc.sample_rate = sr
    enc.layout = "mono"
    enc.format = "s16"
    frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
    frame.sample_rate = sr
    packets = enc.encode(frame) + enc.encode(None)
    return [bytes(p) for p in packets]


def test_websocket_rtp_pcmu_tone_and_noise():
    with TestClient(app) as client:
        for label, payloads, expected in [
            ("tone", pcmu_payloads(sine(8000, 3.0)), "correct_decoder"),
            (
                "noise",
                [
                    bytes(np.random.default_rng(5).integers(0, 256, 160, dtype=np.uint8))
                    for _ in range(150)
                ],
                "incorrect_decoder",
            ),
        ]:
            with client.websocket_connect("/v1/stream") as ws:
                assert ws.receive_json()["type"] == "ready"
                ws.send_json(
                    {
                        "type": "config",
                        "format": "rtp",
                        "payload_type": 0,
                        "codec": "PCMU",
                        "clock_rate": 8000,
                    }
                )
                ws.receive_json()  # configured
                for index, payload in enumerate(payloads):
                    ws.send_bytes(make_rtp(payload, seq=index, ts=index * 160))
                ws.send_json({"type": "eos"})
                while True:
                    message = ws.receive_json()
                    if message["type"] in ("verdict", "error"):
                        break
                assert message["type"] == "verdict", (label, message)
                assert message["verdict"] == expected, (label, message)
