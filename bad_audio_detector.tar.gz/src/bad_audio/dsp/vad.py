from __future__ import annotations

import numpy as np


def rms(frames: np.ndarray) -> np.ndarray:
    return np.sqrt(np.mean(np.asarray(frames, dtype=np.float32) ** 2, axis=1) + 1e-12)


def vad_mask(frames: np.ndarray, sample_rate: int = 16000, threshold: float = 0.01) -> np.ndarray:
    """Energy VAD with a noise-floor-relative threshold."""
    energy = rms(frames)
    if energy.size == 0:
        return np.zeros(0, dtype=bool)
    loud = float(np.percentile(energy, 95))
    gate = max(float(threshold), 0.05 * loud)
    return energy > gate
