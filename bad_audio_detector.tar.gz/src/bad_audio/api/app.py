from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import (
    FastAPI,
    File,
    Form,
    Header,
    HTTPException,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)

from ..config import Settings, get_settings
from ..io.audio import read_pcm
from ..pipeline import Detector
from ..streaming.session import create_session
from .schemas import AnalyzeResponse


def _detector(settings: Settings) -> Detector:
    return getattr(app.state, "detector", None) or Detector.from_settings(settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    if not hasattr(app.state, "detector"):
        app.state.detector = Detector.from_settings(get_settings())
    yield


app = FastAPI(title="Bad Audio Detector", version="0.1.0", lifespan=lifespan)


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}


@app.get("/readyz")
def readyz() -> dict:
    settings = get_settings()
    detector = _detector(settings)
    return {
        "status": "ok",
        "model_version": detector.model_version,
        "mode": settings.app_mode,
    }


@app.post("/v1/analyze", response_model=AnalyzeResponse)
def analyze(
    file: UploadFile = File(...),
    sample_rate: int | None = Form(None),
    pcm_format: str = Form("s16le"),
) -> dict:
    settings = get_settings()
    detector = _detector(settings)
    data = file.file.read()
    if not data:
        raise HTTPException(status_code=400, detail="empty upload")
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail="upload too large")
    name = file.filename or ""
    try:
        if sample_rate is not None or name.lower().endswith(".pcm"):
            if sample_rate is None:
                raise HTTPException(status_code=400, detail="sample_rate is required for PCM")
            pcm = read_pcm(data, sample_rate, pcm_format)
            result = detector.analyze_pcm(pcm)
        else:
            result = detector.analyze_file(data, name)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return result.to_dict()


@app.websocket("/v1/stream")
async def stream(websocket: WebSocket) -> None:
    await websocket.accept()
    await websocket.send_json({"type": "ready"})
    settings = get_settings()
    detector = _detector(settings)
    session = None
    try:
        while True:
            message = await websocket.receive()
            if message.get("type") == "websocket.disconnect":
                break
            if message.get("text") is not None:
                payload = message["text"]
                try:
                    import json

                    event = json.loads(payload)
                except Exception:
                    await websocket.send_json({"type": "error", "detail": "invalid JSON"})
                    break
                if event.get("type") == "config":
                    session = create_session(detector, settings, event)
                    await websocket.send_json(
                        {
                            "type": "configured",
                            "format": session.kind,
                            "codec": session.spec.encoding if session.spec else "PCM",
                        }
                    )
                elif event.get("type") == "eos":
                    if session is not None:
                        result = session.finish()
                        await websocket.send_json({"type": "verdict", **result.to_dict()})
                    else:
                        await websocket.send_json(
                            {"type": "error", "detail": "no stream configured"}
                        )
                    break
                else:
                    await websocket.send_json({"type": "error", "detail": "unknown message"})
                    break
            elif message.get("bytes") is not None:
                if session is None:
                    await websocket.send_json({"type": "error", "detail": "no stream configured"})
                    break
                windows = session.feed(message["bytes"])
                for window in windows:
                    await websocket.send_json(
                        {
                            "type": "window",
                            "start_s": round(window.start_s, 3),
                            "end_s": round(window.end_s, 3),
                            "p_incorrect": round(window.p_incorrect, 4),
                            "insufficient": window.insufficient,
                        }
                    )
    except WebSocketDisconnect:
        return
    except Exception as exc:
        try:
            await websocket.send_json({"type": "error", "detail": str(exc)})
        except Exception:
            pass


@app.post("/v1/admin/reload")
def reload(
    x_admin_token: str | None = Header(default=None),
) -> dict:
    settings = get_settings()
    if settings.admin_token and x_admin_token != settings.admin_token:
        raise HTTPException(status_code=403, detail="forbidden")
    app.state.detector = Detector.from_settings(settings)
    return {"status": "reloaded", "model_version": app.state.detector.model_version}
