from __future__ import annotations

import struct

import pytest

from bad_audio.io.rtp.header import RtpPacket, parse_rtp


def make_packet(
    payload: bytes = b"\x01\x02",
    *,
    pt: int = 0,
    seq: int = 1,
    ts: int = 160,
    ssrc: int = 0xDEADBEEF,
    marker: bool = False,
    csrcs: tuple[int, ...] = (),
    extension: bytes | None = None,
    padding: int = 0,
) -> bytes:
    first = 0x80 | (0x20 if padding else 0) | (0x10 if extension is not None else 0) | len(csrcs)
    second = (0x80 if marker else 0) | pt
    header = struct.pack("!BBHII", first, second, seq, ts, ssrc)
    header += b"".join(struct.pack("!I", c) for c in csrcs)
    if extension is not None:
        header += struct.pack("!HH", 0xBEDE, len(extension) // 4) + extension
    body = payload + (b"\x00" * (padding - 1) + bytes([padding]) if padding else b"")
    return header + body


def test_parse_minimal_header():
    pkt = parse_rtp(make_packet(b"abc", pt=8, seq=7, ts=800, marker=True))
    assert isinstance(pkt, RtpPacket)
    assert pkt.version == 2
    assert pkt.payload_type == 8
    assert pkt.sequence == 7
    assert pkt.timestamp == 800
    assert pkt.ssrc == 0xDEADBEEF
    assert pkt.marker is True
    assert pkt.payload == b"abc"
    assert pkt.payload_offset == 12


def test_parse_csrc_extension_and_padding():
    raw = make_packet(
        b"payload",
        pt=96,
        csrcs=(1, 2),
        extension=b"\x01\x02\x03\x04",
        padding=4,
    )
    pkt = parse_rtp(raw)
    assert pkt.csrc_count == 2
    assert pkt.payload == b"payload"
    assert pkt.payload_offset == 12 + 8 + 8


def test_rejects_short_or_bad_version():
    with pytest.raises(ValueError):
        parse_rtp(b"\x80\x00")
    with pytest.raises(ValueError):
        parse_rtp(b"\x40" + b"\x00" * 11)


def test_rejects_truncated_csrc_and_extension():
    with pytest.raises(ValueError):
        parse_rtp(b"\x82" + b"\x00" * 11)
    with pytest.raises(ValueError):
        parse_rtp(b"\x90" + b"\x00" * 13)
