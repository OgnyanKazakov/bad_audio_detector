from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)


def choose_threshold(
    y_true: np.ndarray,
    scores: np.ndarray,
    min_precision: float = 0.85,
    min_recall: float = 0.98,
) -> float:
    if len(np.unique(y_true)) < 2:
        return 0.5
    precision, recall, thresholds = precision_recall_curve(y_true, scores)
    if thresholds.size == 0:
        return 0.5
    def _midpoint(index: int) -> float:
        low = float(thresholds[index - 1]) if index > 0 else 0.0
        high = float(thresholds[index])
        value = (low + high) / 2.0
        return float(np.clip(value, 0.1, 1.0))

    valid = (precision[:-1] >= min_precision) & (recall[:-1] >= min_recall)
    if valid.any():
        candidates = np.where(valid)[0]
        return _midpoint(int(candidates[0]))
    valid = precision[:-1] >= min_precision
    if valid.any():
        candidates = np.where(valid)[0]
        return _midpoint(int(candidates[0]))
    return 0.5


def binary_metrics(y_true: np.ndarray, scores: np.ndarray, threshold: float) -> dict:
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)
    pred = (scores >= threshold).astype(int)
    out = {
        "threshold": float(threshold),
        "n": int(len(y_true)),
        "positives": int(y_true.sum()),
        "accuracy": float(np.mean(pred == y_true)) if len(y_true) else 0.0,
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall": float(recall_score(y_true, pred, zero_division=0)),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
    }
    if len(np.unique(y_true)) > 1:
        out["roc_auc"] = float(roc_auc_score(y_true, scores))
    else:
        out["roc_auc"] = None
    cm = confusion_matrix(y_true, pred, labels=[0, 1])
    out["confusion_matrix"] = cm.tolist()
    return out
