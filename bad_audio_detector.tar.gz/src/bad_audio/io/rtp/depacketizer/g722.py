from __future__ import annotations

from .base import Depacketizer, EncodedFrame


class G722Depacketizer(Depacketizer):
    def depacketize(self, packet, spec) -> list[EncodedFrame]:
        if not packet.payload:
            return []
        # 64 kbit/s: one payload octet per 8 kHz sample interval.
        return [
            EncodedFrame(
                codec=spec.encoding,
                data=packet.payload,
                rtp_timestamp=packet.timestamp,
                duration=len(packet.payload),
                sample_rate=spec.sample_rate,
                channels=1,
                sequence=packet.sequence,
            )
        ]
